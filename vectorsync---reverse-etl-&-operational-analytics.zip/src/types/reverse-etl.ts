export type WarehouseType = 'snowflake' | 'bigquery' | 'databricks' | 'redshift' | 'postgres';

export type DestinationType =
  | 'salesforce'
  | 'hubspot'
  | 'google_ads'
  | 'meta_ads'
  | 'braze'
  | 'zendesk'
  | 'slack'
  | 'webhook';

export type SyncMode = 'upsert' | 'insert' | 'mirror' | 'update_only';

export type SyncScheduleType = 'continuous' | 'hourly' | 'daily' | 'cron' | 'dbt_cloud_webhook' | 'manual';

export type SyncStatus = 'healthy' | 'running' | 'paused' | 'failed' | 'drift_detected';

export interface WarehouseSource {
  id: string;
  name: string;
  type: WarehouseType;
  host: string;
  database: string;
  schema: string;
  warehouseSize?: string;
  status: 'connected' | 'checking' | 'error';
  latencyMs: number;
  modelsCount: number;
  lastTestedAt: string;
  tables: {
    name: string;
    rowCount: number;
    columns: { name: string; type: string; isNullable: boolean }[];
  }[];
}

export interface DataModel {
  id: string;
  name: string;
  description: string;
  sourceId: string;
  type: 'sql' | 'dbt' | 'visual_table';
  sqlQuery?: string;
  dbtModelName?: string;
  dbtTags?: string[];
  primaryKey: string;
  columns: { name: string; type: string; sampleValue: string | number | boolean }[];
  sampleData: Record<string, any>[];
  lastCompiledAt: string;
  rowCount: number;
}

export interface Destination {
  id: string;
  name: string;
  type: DestinationType;
  authType: 'oauth' | 'api_key';
  accountName: string;
  status: 'connected' | 'rate_limited' | 'error';
  apiCallsRemaining: number;
  apiCallsLimit: number;
  resetTime: string;
  batchSize: number;
  supportedObjects: {
    id: string;
    label: string;
    identifierFields: string[];
    fields: { name: string; label: string; type: string; required: boolean; readOnly?: boolean }[];
  }[];
}

export type TransformType =
  | 'direct'
  | 'uppercase'
  | 'lowercase'
  | 'trim'
  | 'sha256'
  | 'to_integer'
  | 'to_float'
  | 'to_boolean'
  | 'to_iso_timestamp'
  | 'default_value'
  | 'extract_domain';

export interface FieldMapping {
  id: string;
  sourceColumn: string;
  destinationField: string;
  transform: TransformType;
  defaultValue?: string;
  isIdentifier?: boolean;
}

export interface SyncConfig {
  id: string;
  name: string;
  description: string;
  sourceModelId: string;
  destinationId: string;
  destinationObject: string;
  syncMode: SyncMode;
  sourceIdentifier: string;
  destinationIdentifier: string;
  mappings: FieldMapping[];
  schedule: {
    type: SyncScheduleType;
    cronExpression?: string;
    intervalMinutes?: number;
    dailyTimeUtc?: string;
  };
  status: SyncStatus;
  enabled: boolean;
  lastRunAt?: string;
  lastRunDurationSec?: number;
  totalSyncedCount: number;
  driftAlert?: SchemaDriftAlert;
}

export interface SyncRunLog {
  id: string;
  syncId: string;
  syncName: string;
  startedAt: string;
  finishedAt?: string;
  status: 'running' | 'completed' | 'failed' | 'dry_run_completed';
  isDryRun: boolean;
  durationSec: number;
  recordsRead: number;
  recordsAdded: number;
  recordsUpdated: number;
  recordsUnchanged: number;
  recordsFailed: number;
  throughputPerSec: number;
  logs: {
    timestamp: string;
    level: 'info' | 'warn' | 'error';
    message: string;
  }[];
  quarantineSample?: QuarantinedRecord[];
}

export interface QuarantinedRecord {
  id: string;
  syncId: string;
  recordIdentifier: string;
  errorReason: string;
  rawPayload: Record<string, any>;
  occurredAt: string;
  retryStatus: 'pending' | 'retrying' | 'resolved' | 'ignored';
}

export interface SchemaDriftAlert {
  id: string;
  syncId: string;
  syncName: string;
  detectedAt: string;
  driftType: 'missing_column' | 'type_mismatch' | 'destination_field_removed';
  columnName: string;
  expected: string;
  actual: string;
  status: 'unresolved' | 'resolved' | 'dismissed';
}
