import { FieldMapping, SyncConfig, DataModel, SyncRunLog, QuarantinedRecord } from '../types/reverse-etl';

// Simple synchronous string hasher for demonstration (SHA-256 simulation in pure TS without external crypto dependency)
export function simulateSha256(input: string): string {
  if (!input) return '';
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return `sha256_${hex}${hex}${hex}${hex}`.slice(0, 64);
}

export function applyTransform(value: any, mapping: FieldMapping): any {
  if (value === undefined || value === null) {
    if (mapping.transform === 'default_value' && mapping.defaultValue) {
      return mapping.defaultValue;
    }
    return '';
  }

  const str = String(value);

  switch (mapping.transform) {
    case 'uppercase':
      return str.toUpperCase();
    case 'lowercase':
      return str.toLowerCase();
    case 'trim':
      return str.trim();
    case 'sha256':
      return simulateSha256(str.trim().toLowerCase());
    case 'to_integer':
      const intVal = parseInt(str, 10);
      return isNaN(intVal) ? 0 : intVal;
    case 'to_float':
      const floatVal = parseFloat(str);
      return isNaN(floatVal) ? 0.0 : floatVal;
    case 'to_boolean':
      return str === 'true' || str === '1' || str === 't';
    case 'extract_domain':
      if (str.includes('@')) {
        return str.split('@')[1]?.toLowerCase();
      }
      return str.replace(/^https?:\/\//, '').split('/')[0];
    case 'to_iso_timestamp':
      try {
        return new Date(str).toISOString();
      } catch {
        return str;
      }
    case 'default_value':
      return str || mapping.defaultValue || '';
    case 'direct':
    default:
      return value;
  }
}

export interface DiffSampleResult {
  sourceRaw: Record<string, any>;
  transformedPayload: Record<string, any>;
  action: 'insert' | 'update' | 'unchanged';
  primaryKey: string;
}

export function calculateDryRunDiff(sync: SyncConfig, model: DataModel): DiffSampleResult[] {
  if (!model.sampleData || model.sampleData.length === 0) return [];

  return model.sampleData.map((row, idx) => {
    const transformed: Record<string, any> = {};

    sync.mappings.forEach((m) => {
      const sourceVal = row[m.sourceColumn];
      transformed[m.destinationField] = applyTransform(sourceVal, m);
    });

    const primaryKeyVal = String(row[sync.sourceIdentifier] || '');
    // Alternate simulated diff actions
    const action: 'insert' | 'update' | 'unchanged' =
      idx === 0 ? 'insert' : idx === 1 ? 'update' : idx % 2 === 0 ? 'update' : 'unchanged';

    return {
      sourceRaw: row,
      transformedPayload: transformed,
      action,
      primaryKey: primaryKeyVal,
    };
  });
}
