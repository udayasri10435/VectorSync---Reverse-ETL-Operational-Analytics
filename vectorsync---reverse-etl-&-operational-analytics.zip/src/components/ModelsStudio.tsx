import React, { useState } from 'react';
import { DataModel, WarehouseSource } from '../types/reverse-etl';
import {
  Database,
  Code2,
  Play,
  Layers,
  Sparkles,
  GitBranch,
  Search,
  Plus,
  Clock,
  Terminal,
  Filter,
} from 'lucide-react';

interface ModelsStudioProps {
  models: DataModel[];
  warehouses: WarehouseSource[];
  onCreateModel: (newModel: DataModel) => void;
}

export const ModelsStudio: React.FC<ModelsStudioProps> = ({
  models,
  warehouses,
  onCreateModel,
}) => {
  const [selectedModelId, setSelectedModelId] = useState<string>(models[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'sql' | 'preview' | 'schema' | 'dbt'>('preview');
  const [searchQuery, setSearchQuery] = useState('');
  const [isExecutingQuery, setIsExecutingQuery] = useState(false);
  const [queryExecutionStats, setQueryExecutionStats] = useState<{
    durationMs: number;
    rowsReturned: number;
  }>({ durationMs: 194, rowsReturned: 4 });

  const selectedModel = models.find((m) => m.id === selectedModelId) || models[0];
  const [currentSql, setCurrentSql] = useState(selectedModel?.sqlQuery || '');

  React.useEffect(() => {
    if (selectedModel) {
      setCurrentSql(selectedModel.sqlQuery || '');
    }
  }, [selectedModelId]);

  const warehouse = warehouses.find((w) => w.id === selectedModel?.sourceId);

  const handleRunQuery = () => {
    setIsExecutingQuery(true);
    setTimeout(() => {
      setIsExecutingQuery(false);
      setQueryExecutionStats({
        durationMs: Math.floor(Math.random() * 120 + 80),
        rowsReturned: selectedModel.sampleData.length,
      });
      setActiveTab('preview');
    }, 600);
  };

  const filteredModels = models.filter((m) =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-5">
      {/* Studio Header & Model Switcher */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Warehouse Models & SQL Studio</h2>
          <p className="text-xs text-slate-400">
            Define warehouse queries, connect dbt models, and preview data before activating downstream operational syncs
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const newModel: DataModel = {
                id: `model-${Date.now()}`,
                name: 'High ARR Expansion Prospects',
                description: 'Accounts with >$50k ARR and >90% license utilization ready for tier upgrade.',
                sourceId: warehouses[0]?.id || 'wh-snowflake-prod',
                type: 'sql',
                primaryKey: 'account_id',
                rowCount: 850,
                lastCompiledAt: 'Just now',
                sqlQuery: `SELECT account_id, company_name, arr_usd, plan_tier, health_score\nFROM PROD_ANALYTICS.MARTS_OPERATIONAL.dim_customer_360\nWHERE arr_usd >= 50000 AND health_score > 85;`,
                columns: [
                  { name: 'account_id', type: 'VARCHAR', sampleValue: 'acc_5510' },
                  { name: 'company_name', type: 'VARCHAR', sampleValue: 'Stark Industries' },
                  { name: 'arr_usd', type: 'NUMBER', sampleValue: 84000 },
                  { name: 'plan_tier', type: 'VARCHAR', sampleValue: 'Enterprise' },
                  { name: 'health_score', type: 'NUMBER', sampleValue: 92 },
                ],
                sampleData: [
                  {
                    account_id: 'acc_5510',
                    company_name: 'Stark Industries',
                    arr_usd: 84000,
                    plan_tier: 'Enterprise',
                    health_score: 92,
                  },
                  {
                    account_id: 'acc_5511',
                    company_name: 'Wayne Enterprises',
                    arr_usd: 120000,
                    plan_tier: 'Enterprise VIP',
                    health_score: 96,
                  },
                ],
              };
              onCreateModel(newModel);
              setSelectedModelId(newModel.id);
            }}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>New Model</span>
          </button>
        </div>
      </div>

      {/* Main Studio Grid: Left Sidebar (Model list) + Right Editor/Preview Viewport */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Left Col: Models Navigator */}
        <div className="lg:col-span-1 space-y-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search models..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="space-y-1.5 max-h-[600px] overflow-y-auto">
            {filteredModels.map((model) => (
              <div
                key={model.id}
                onClick={() => setSelectedModelId(model.id)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  selectedModelId === model.id
                    ? 'border-indigo-500 bg-indigo-950/40 text-white'
                    : 'border-slate-800/80 bg-slate-900/60 hover:bg-slate-900 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-xs font-semibold truncate">{model.name}</span>
                  <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-400 px-1 py-0.2 rounded shrink-0">
                    {model.type}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 line-clamp-1">{model.description}</div>
                <div className="mt-2 flex items-center justify-between text-[10px] font-mono text-slate-500">
                  <span>PK: {model.primaryKey}</span>
                  <span>{model.rowCount.toLocaleString()} rows</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 3 Cols: Active Model Studio */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800/80 rounded-xl overflow-hidden flex flex-col">
          {/* Top Bar of active model */}
          <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950/40">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-bold text-white tracking-tight">{selectedModel.name}</h3>
                <span className="text-xs font-mono uppercase bg-indigo-950/80 text-indigo-300 border border-indigo-800/60 px-2 py-0.5 rounded">
                  Source: {warehouse?.name || 'Snowflake'}
                </span>
                {selectedModel.type === 'dbt' && (
                  <span className="text-xs font-mono text-cyan-300 bg-cyan-950/80 border border-cyan-800/60 px-2 py-0.5 rounded flex items-center gap-1">
                    <GitBranch className="w-3 h-3" />
                    <span>dbt model</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1">{selectedModel.description}</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleRunQuery}
                disabled={isExecutingQuery}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-indigo-600/30 disabled:opacity-50"
              >
                <Play className={`w-3.5 h-3.5 fill-white ${isExecutingQuery ? 'animate-pulse' : ''}`} />
                <span>{isExecutingQuery ? 'Querying...' : 'Run Query'}</span>
              </button>
            </div>
          </div>

          {/* Sub Navigation Tabs */}
          <div className="px-4 pt-2 border-b border-slate-800 flex items-center justify-between bg-slate-950/20">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
                  activeTab === 'preview'
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Data Preview ({selectedModel.sampleData.length} records)
              </button>
              <button
                onClick={() => setActiveTab('sql')}
                className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
                  activeTab === 'sql'
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>SQL Query Editor</span>
              </button>
              <button
                onClick={() => setActiveTab('schema')}
                className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
                  activeTab === 'schema'
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Columns Schema ({selectedModel.columns.length})
              </button>
              {selectedModel.type === 'dbt' && (
                <button
                  onClick={() => setActiveTab('dbt')}
                  className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
                    activeTab === 'dbt'
                      ? 'border-indigo-500 text-white'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  dbt Lineage & Tags
                </button>
              )}
            </div>

            <div className="text-[11px] font-mono text-slate-500 hidden sm:flex items-center gap-3">
              <span>Duration: {queryExecutionStats.durationMs}ms</span>
              <span>·</span>
              <span>Warehouse: {warehouse?.warehouseSize || 'X-Small'}</span>
            </div>
          </div>

          {/* Tab 1: Tabular Data Preview */}
          {activeTab === 'preview' && (
            <div className="p-4 flex-1 flex flex-col justify-between overflow-x-auto space-y-3">
              <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-950/60">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 font-medium border-b border-slate-800">
                    <tr>
                      {selectedModel.columns.map((col) => (
                        <th key={col.name} className="px-4 py-2 font-mono whitespace-nowrap">
                          <div className="text-slate-200">{col.name}</div>
                          <div className="text-[10px] text-slate-500 font-normal uppercase">{col.type}</div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {selectedModel.sampleData.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-900/60 transition-colors">
                        {selectedModel.columns.map((col) => (
                          <td key={col.name} className="px-4 py-2.5 text-slate-300 whitespace-nowrap">
                            {row[col.name] !== undefined && row[col.name] !== null ? (
                              String(row[col.name])
                            ) : (
                              <span className="text-slate-600 italic">null</span>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-1">
                <span>Showing first {selectedModel.sampleData.length} preview records of {selectedModel.rowCount.toLocaleString()} total rows</span>
                <span className="text-emerald-400">Query compiled successfully</span>
              </div>
            </div>
          )}

          {/* Tab 2: SQL Editor */}
          {activeTab === 'sql' && (
            <div className="p-4 space-y-3 flex-1 flex flex-col">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Interactive Warehouse SQL (Dialect: {warehouse?.type.toUpperCase() || 'SNOWFLAKE'})</span>
                <button
                  onClick={handleRunQuery}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
                >
                  Format & Test Query ➔
                </button>
              </div>

              <div className="relative flex-1">
                <textarea
                  value={currentSql}
                  onChange={(e) => setCurrentSql(e.target.value)}
                  rows={9}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 font-mono text-xs text-indigo-200 focus:outline-none focus:border-indigo-500 leading-relaxed resize-y"
                  placeholder="SELECT * FROM my_schema.my_table..."
                />
              </div>

              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg text-xs text-slate-400 flex items-center justify-between">
                <span>Variables support: <code className="font-mono text-indigo-300">{'{{ env }}'}</code>, <code className="font-mono text-indigo-300">{'{{ ref(...) }}'}</code></span>
                <span className="text-slate-500 font-mono">Zero-copy warehouse execution</span>
              </div>
            </div>
          )}

          {/* Tab 3: Schema Columns */}
          {activeTab === 'schema' && (
            <div className="p-4 space-y-3 flex-1">
              <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-950/60">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 font-medium border-b border-slate-800">
                    <tr>
                      <th className="px-4 py-2 font-mono">Column Name</th>
                      <th className="px-4 py-2 font-mono">Data Type</th>
                      <th className="px-4 py-2 font-mono">Sample Value</th>
                      <th className="px-4 py-2 font-mono">Key Role</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {selectedModel.columns.map((col) => (
                      <tr key={col.name} className="hover:bg-slate-900/60">
                        <td className="px-4 py-2.5 text-white font-medium">{col.name}</td>
                        <td className="px-4 py-2.5 text-cyan-400">{col.type}</td>
                        <td className="px-4 py-2.5 text-slate-400">{String(col.sampleValue)}</td>
                        <td className="px-4 py-2.5">
                          {col.name === selectedModel.primaryKey ? (
                            <span className="text-[10px] font-mono uppercase bg-indigo-950 text-indigo-300 border border-indigo-800 px-2 py-0.5 rounded">
                              Unique Identifier
                            </span>
                          ) : (
                            <span className="text-slate-500">Attribute</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tab 4: dbt Lineage */}
          {activeTab === 'dbt' && selectedModel.type === 'dbt' && (
            <div className="p-4 space-y-4 flex-1 text-xs">
              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">dbt Cloud Model Metadata</span>
                  <span className="text-emerald-400 font-mono">Artifacts Synced</span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-slate-400">
                  <div>Model Name: <code className="text-white font-mono">{selectedModel.dbtModelName}</code></div>
                  <div>Git Branch: <code className="text-white font-mono">main</code></div>
                  <div>Warehouse Target: <code className="text-white font-mono">prod_snowflake</code></div>
                  <div>Last Run Status: <span className="text-emerald-400 font-mono">Passed (Tests: 6/6)</span></div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
                  <span className="text-slate-400">dbt Tags:</span>
                  {selectedModel.dbtTags?.map((tag) => (
                    <span key={tag} className="font-mono text-cyan-300 bg-cyan-950/80 border border-cyan-800 px-2 py-0.5 rounded">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
