import React, { useState } from 'react';
import { WarehouseSource, WarehouseType } from '../types/reverse-etl';
import {
  Database,
  CheckCircle2,
  Activity,
  Plus,
  Table,
  RotateCw,
  Search,
  ExternalLink,
  ShieldCheck,
  Server,
  X,
} from 'lucide-react';

interface SourcesViewProps {
  warehouses: WarehouseSource[];
  onAddWarehouse: (source: WarehouseSource) => void;
}

export const SourcesView: React.FC<SourcesViewProps> = ({ warehouses, onAddWarehouse }) => {
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>(warehouses[0]?.id || '');
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; latency: number } | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New warehouse form state
  const [newWhName, setNewWhName] = useState('');
  const [newWhType, setNewWhType] = useState<WarehouseType>('snowflake');
  const [newWhHost, setNewWhHost] = useState('');
  const [newWhDb, setNewWhDb] = useState('');
  const [newWhSchema, setNewWhSchema] = useState('');

  const selectedWh = warehouses.find((w) => w.id === selectedWarehouseId) || warehouses[0];

  const handleTestConnection = (id: string) => {
    setTestingId(id);
    setTimeout(() => {
      setTestingId(null);
      setTestResult({ id, latency: Math.floor(Math.random() * 25 + 25) });
    }, 700);
  };

  const handleSaveWarehouse = () => {
    const newWh: WarehouseSource = {
      id: `wh-${Date.now()}`,
      name: newWhName || `${newWhType.toUpperCase()} Warehouse`,
      type: newWhType,
      host: newWhHost || 'warehouse.us-east-1.cloud.net',
      database: newWhDb || 'PROD_DB',
      schema: newWhSchema || 'PUBLIC',
      status: 'connected',
      latencyMs: 34,
      modelsCount: 0,
      lastTestedAt: 'Just now',
      tables: [
        {
          name: 'users_operational',
          rowCount: 24000,
          columns: [
            { name: 'id', type: 'VARCHAR', isNullable: false },
            { name: 'email', type: 'VARCHAR', isNullable: false },
            { name: 'created_at', type: 'TIMESTAMP', isNullable: false },
          ],
        },
      ],
    };

    onAddWarehouse(newWh);
    setIsAddModalOpen(false);
    setSelectedWarehouseId(newWh.id);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Warehouse Sources</h2>
          <p className="text-xs text-slate-400">
            Connect data warehouses to extract snapshots, compute incremental diffs, and power operational models
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>Connect Warehouse</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left Column: Warehouse List */}
        <div className="space-y-3">
          {warehouses.map((wh) => (
            <div
              key={wh.id}
              onClick={() => setSelectedWarehouseId(wh.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                selectedWarehouseId === wh.id
                  ? 'border-indigo-500 bg-indigo-950/40 text-white'
                  : 'border-slate-800/80 bg-slate-900/60 hover:bg-slate-900 text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-indigo-400" />
                  <span className="text-sm font-semibold">{wh.name}</span>
                </div>
                <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-400 px-2 py-0.5 rounded">
                  {wh.type}
                </span>
              </div>

              <div className="text-xs text-slate-400 font-mono truncate">{wh.host}</div>

              <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">Connected ({wh.latencyMs}ms)</span>
                </div>
                <span className="text-slate-500 font-mono text-[11px]">{wh.modelsCount} models</span>
              </div>
            </div>
          ))}
        </div>

        {/* Right 2 Columns: Warehouse Catalog & Inspector */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-xl overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950/40">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">{selectedWh.name}</h3>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded">
                  Healthy
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Database: <code className="text-indigo-300 font-mono">{selectedWh.database}</code> · Schema:{' '}
                <code className="text-indigo-300 font-mono">{selectedWh.schema}</code>
              </p>
            </div>

            <button
              onClick={() => handleTestConnection(selectedWh.id)}
              disabled={testingId === selectedWh.id}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <RotateCw className={`w-3.5 h-3.5 ${testingId === selectedWh.id ? 'animate-spin text-indigo-400' : ''}`} />
              <span>{testingId === selectedWh.id ? 'Pinging...' : 'Test Connection'}</span>
            </button>
          </div>

          {/* Test results banner */}
          {testResult && testResult.id === selectedWh.id && (
            <div className="bg-emerald-950/50 border-b border-emerald-800/60 px-5 py-2.5 text-xs text-emerald-200 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Handshake successful! Live roundtrip latency: <strong>{testResult.latency}ms</strong></span>
              </span>
              <span className="text-slate-400 font-mono">TLS 1.3 Verified</span>
            </div>
          )}

          {/* Tables and Catalog */}
          <div className="p-5 space-y-4 flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Discovered Tables & Views in {selectedWh.schema}
              </h4>
              <span className="text-xs font-mono text-slate-500">
                {selectedWh.tables.length} tables cataloged
              </span>
            </div>

            <div className="space-y-3">
              {selectedWh.tables.map((table) => (
                <div
                  key={table.name}
                  className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Table className="w-4 h-4 text-indigo-400" />
                      <span className="text-xs font-mono font-semibold text-white">{table.name}</span>
                    </div>
                    <span className="text-xs font-mono text-slate-400 tabular-nums">
                      {table.rowCount.toLocaleString()} rows
                    </span>
                  </div>

                  {/* Columns list */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {table.columns.map((col) => (
                      <span
                        key={col.name}
                        className="text-[11px] font-mono bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-slate-300"
                      >
                        {col.name}{' '}
                        <span className="text-slate-500 text-[10px]">({col.type})</span>
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Add Warehouse Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Connect Warehouse Source</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1">Warehouse Type</label>
                <select
                  value={newWhType}
                  onChange={(e) => setNewWhType(e.target.value as WarehouseType)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white"
                >
                  <option value="snowflake">Snowflake</option>
                  <option value="bigquery">Google BigQuery</option>
                  <option value="databricks">Databricks Unity Catalog</option>
                  <option value="redshift">AWS Redshift</option>
                  <option value="postgres">PostgreSQL / Timescale</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Display Name</label>
                <input
                  type="text"
                  placeholder="e.g. Snowflake Production Marts"
                  value={newWhName}
                  onChange={(e) => setNewWhName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Host / Account Identifier</label>
                <input
                  type="text"
                  placeholder="e.g. xy12345.us-east-1.snowflakecomputing.com"
                  value={newWhHost}
                  onChange={(e) => setNewWhHost(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300 block mb-1">Database</label>
                  <input
                    type="text"
                    placeholder="PROD_DW"
                    value={newWhDb}
                    onChange={(e) => setNewWhDb(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1">Schema</label>
                  <input
                    type="text"
                    placeholder="ANALYTICS"
                    value={newWhSchema}
                    onChange={(e) => setNewWhSchema(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="px-3.5 py-1.5 text-xs text-slate-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveWarehouse}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm"
              >
                Save & Authenticate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
