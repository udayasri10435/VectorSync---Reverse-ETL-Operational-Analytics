import React, { useState } from 'react';
import {
  SyncConfig,
  DataModel,
  Destination,
  SyncRunLog,
  FieldMapping,
  TransformType,
} from '../types/reverse-etl';
import {
  X,
  Play,
  Eye,
  Plus,
  Trash2,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Code,
  Layers,
  Database,
  ShieldAlert,
} from 'lucide-react';
import { calculateDryRunDiff, applyTransform } from '../utils/syncEngine';

interface SyncDetailModalProps {
  sync: SyncConfig;
  model: DataModel;
  destination: Destination;
  runs: SyncRunLog[];
  onClose: () => void;
  onUpdateMappings: (syncId: string, mappings: FieldMapping[]) => void;
  onTriggerSync: (sync: SyncConfig, isDryRun?: boolean) => void;
  onAutoRemapDrift: (syncId: string) => void;
}

export const SyncDetailModal: React.FC<SyncDetailModalProps> = ({
  sync,
  model,
  destination,
  runs,
  onClose,
  onUpdateMappings,
  onTriggerSync,
  onAutoRemapDrift,
}) => {
  const [activeTab, setActiveTab] = useState<'mappings' | 'diff' | 'history' | 'config'>('mappings');
  const [mappings, setMappings] = useState<FieldMapping[]>(sync.mappings);
  const [hasChanges, setHasChanges] = useState(false);

  // Available destination fields for this object
  const destObject = destination.supportedObjects.find((o) => o.id === sync.destinationObject);
  const destFields = destObject?.fields || [];
  const sourceColumns = model.columns || [];

  const handleTransformChange = (mappingId: string, transform: TransformType) => {
    setMappings((prev) =>
      prev.map((m) => (m.id === mappingId ? { ...m, transform } : m))
    );
    setHasChanges(true);
  };

  const handleSourceColChange = (mappingId: string, sourceColumn: string) => {
    setMappings((prev) =>
      prev.map((m) => (m.id === mappingId ? { ...m, sourceColumn } : m))
    );
    setHasChanges(true);
  };

  const handleDestFieldChange = (mappingId: string, destinationField: string) => {
    setMappings((prev) =>
      prev.map((m) => (m.id === mappingId ? { ...m, destinationField } : m))
    );
    setHasChanges(true);
  };

  const handleDefaultValChange = (mappingId: string, defaultValue: string) => {
    setMappings((prev) =>
      prev.map((m) => (m.id === mappingId ? { ...m, defaultValue } : m))
    );
    setHasChanges(true);
  };

  const handleRemoveMapping = (mappingId: string) => {
    setMappings((prev) => prev.filter((m) => m.id !== mappingId));
    setHasChanges(true);
  };

  const handleAddMapping = () => {
    const unmappedSource = sourceColumns.find(
      (sc) => !mappings.some((m) => m.sourceColumn === sc.name)
    );
    const unmappedDest = destFields.find(
      (df) => !mappings.some((m) => m.destinationField === df.name)
    );

    const newMapping: FieldMapping = {
      id: `map_${Date.now()}`,
      sourceColumn: unmappedSource ? unmappedSource.name : sourceColumns[0]?.name || '',
      destinationField: unmappedDest ? unmappedDest.name : destFields[0]?.name || '',
      transform: 'direct',
    };

    setMappings((prev) => [...prev, newMapping]);
    setHasChanges(true);
  };

  const handleSaveMappings = () => {
    onUpdateMappings(sync.id, mappings);
    setHasChanges(false);
  };

  // Calculate live diff based on current mappings
  const diffResults = calculateDryRunDiff({ ...sync, mappings }, model);

  // Filter runs for this sync
  const syncRuns = runs.filter((r) => r.syncId === sync.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between gap-4 bg-slate-950/60">
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h2 className="text-lg font-bold text-white tracking-tight">{sync.name}</h2>
              {sync.status === 'drift_detected' ? (
                <span className="text-xs font-mono text-amber-400 bg-amber-950/80 border border-amber-800/60 px-2 py-0.5 rounded flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Drift Detected</span>
                </span>
              ) : (
                <span className="text-xs font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded">
                  Healthy
                </span>
              )}
              <span className="text-xs font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                Mode: {sync.syncMode}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Source: <strong className="text-slate-200">{model.name}</strong> ➔ Destination:{' '}
              <strong className="text-slate-200">{destination.name}</strong> ({sync.destinationObject})
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onTriggerSync(sync, true)}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5 text-slate-400" />
              <span>Dry Run</span>
            </button>
            <button
              onClick={() => onTriggerSync(sync, false)}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>Run Sync Now</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Schema Drift Warning Alert banner if present */}
        {sync.driftAlert && sync.driftAlert.status === 'unresolved' && (
          <div className="bg-amber-950/50 border-b border-amber-800/70 px-6 py-3 flex items-center justify-between gap-3 text-xs text-amber-200">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                Schema Drift Alert: column <code className="font-mono text-white">{sync.driftAlert.columnName}</code>: {sync.driftAlert.actual}
              </span>
            </div>
            <button
              onClick={() => onAutoRemapDrift(sync.id)}
              className="px-2.5 py-1 text-xs font-semibold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap"
            >
              Auto-Remap & Clear Alert
            </button>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="px-6 pt-3 border-b border-slate-800 flex items-center gap-2 bg-slate-900/40">
          <button
            onClick={() => setActiveTab('mappings')}
            className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'mappings'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Field Mappings ({mappings.length})</span>
            {hasChanges && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>}
          </button>
          <button
            onClick={() => setActiveTab('diff')}
            className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'diff'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Live Dry-Run Diff ({diffResults.length} records)</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Run History ({syncRuns.length})
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'config'
                ? 'border-indigo-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Schedule & Triggers
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* TAB 1: FIELD MAPPINGS */}
          {activeTab === 'mappings' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">Source to Destination Field Mappings</h3>
                  <p className="text-xs text-slate-400">
                    Transform data in-flight before it is batched to the downstream destination API
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAddMapping}
                    className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Field</span>
                  </button>
                  {hasChanges && (
                    <button
                      onClick={handleSaveMappings}
                      className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors"
                    >
                      Save Changes
                    </button>
                  )}
                </div>
              </div>

              {/* Mappings Table */}
              <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/40">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/80 text-slate-400 font-medium border-b border-slate-800">
                    <tr>
                      <th className="px-4 py-2.5">Warehouse Column</th>
                      <th className="px-4 py-2.5">In-Flight Transformation</th>
                      <th className="px-4 py-2.5">Target Destination Field</th>
                      <th className="px-4 py-2.5">Sample Output</th>
                      <th className="px-4 py-2.5 text-center">Key</th>
                      <th className="px-4 py-2.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {mappings.map((m) => {
                      const sampleRow = model.sampleData[0] || {};
                      const rawVal = sampleRow[m.sourceColumn];
                      const transformedVal = applyTransform(rawVal, m);

                      return (
                        <tr key={m.id} className="hover:bg-slate-900/60 transition-colors">
                          {/* Warehouse source column */}
                          <td className="px-4 py-3">
                            <select
                              value={m.sourceColumn}
                              onChange={(e) => handleSourceColChange(m.id, e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 font-mono text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                            >
                              {sourceColumns.map((col) => (
                                <option key={col.name} value={col.name}>
                                  {col.name} ({col.type})
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* Transformation operator */}
                          <td className="px-4 py-3">
                            <select
                              value={m.transform}
                              onChange={(e) => handleTransformChange(m.id, e.target.value as TransformType)}
                              className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-300 text-xs focus:outline-none focus:border-indigo-500 font-medium"
                            >
                              <option value="direct">Direct (Passthrough)</option>
                              <option value="uppercase">UPPERCASE</option>
                              <option value="lowercase">lowercase</option>
                              <option value="trim">Trim whitespace</option>
                              <option value="sha256">SHA-256 Hash (Google/Meta match)</option>
                              <option value="to_integer">Cast to Integer</option>
                              <option value="to_float">Cast to Float</option>
                              <option value="to_boolean">Cast to Boolean</option>
                              <option value="to_iso_timestamp">Convert to ISO Timestamp</option>
                              <option value="extract_domain">Extract Domain</option>
                              <option value="default_value">Default Value if Null</option>
                            </select>

                            {m.transform === 'default_value' && (
                              <input
                                type="text"
                                placeholder="Fallback default..."
                                value={m.defaultValue || ''}
                                onChange={(e) => handleDefaultValChange(m.id, e.target.value)}
                                className="mt-1.5 w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-300 text-[11px]"
                              />
                            )}
                          </td>

                          {/* Target destination field */}
                          <td className="px-4 py-3">
                            <select
                              value={m.destinationField}
                              onChange={(e) => handleDestFieldChange(m.id, e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 font-mono text-cyan-300 text-xs focus:outline-none focus:border-indigo-500"
                            >
                              {destFields.map((field) => (
                                <option key={field.name} value={field.name}>
                                  {field.name} {field.required ? '*(Req)' : ''}
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* Sample Transformed Preview */}
                          <td className="px-4 py-3 font-mono text-slate-400 text-[11px] max-w-xs truncate">
                            <span className="text-slate-300" title={String(transformedVal)}>
                              {String(transformedVal)}
                            </span>
                          </td>

                          {/* Primary Identifier Key */}
                          <td className="px-4 py-3 text-center">
                            {m.isIdentifier ? (
                              <span className="text-[10px] font-mono uppercase bg-indigo-950 text-indigo-300 border border-indigo-800/80 px-1.5 py-0.5 rounded font-semibold">
                                Primary Key
                              </span>
                            ) : (
                              <span className="text-slate-600">-</span>
                            )}
                          </td>

                          {/* Action */}
                          <td className="px-4 py-3 text-right">
                            {!m.isIdentifier && (
                              <button
                                onClick={() => handleRemoveMapping(m.id)}
                                className="text-slate-500 hover:text-rose-400 p-1 rounded transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: LIVE DRY-RUN DIFF */}
          {activeTab === 'diff' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">
                    Live In-Memory Diff & Dry-Run Inspector
                  </h3>
                  <p className="text-xs text-slate-400">
                    Compares current warehouse state against destination snapshot to determine exact Net-New Inserts and Updates
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono">
                  <span className="flex items-center gap-1.5 text-cyan-400">
                    <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                    <span>Insert: 1</span>
                  </span>
                  <span className="flex items-center gap-1.5 text-indigo-400">
                    <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                    <span>Update: {Math.max(1, diffResults.length - 2)}</span>
                  </span>
                  <span className="flex items-center gap-1.5 text-slate-400">
                    <span className="w-2 h-2 rounded-full bg-slate-500"></span>
                    <span>Unchanged: 1</span>
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                {diffResults.map((diff, idx) => (
                  <div
                    key={idx}
                    className="border border-slate-800 bg-slate-950/60 rounded-xl p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-slate-400">Match Key:</span>
                        <span className="text-xs font-mono text-white font-semibold">
                          {diff.primaryKey}
                        </span>
                      </div>
                      <div>
                        {diff.action === 'insert' && (
                          <span className="text-xs font-mono text-cyan-300 bg-cyan-950/80 border border-cyan-800/80 px-2 py-0.5 rounded font-medium">
                            + INSERT (Net New)
                          </span>
                        )}
                        {diff.action === 'update' && (
                          <span className="text-xs font-mono text-indigo-300 bg-indigo-950/80 border border-indigo-800/80 px-2 py-0.5 rounded font-medium">
                            ~ UPDATE (Modified Fields)
                          </span>
                        )}
                        {diff.action === 'unchanged' && (
                          <span className="text-xs font-mono text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded">
                            UNCHANGED (Skipped)
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                      <div className="bg-slate-900/80 border border-slate-800 rounded p-3">
                        <div className="text-[11px] text-slate-400 mb-1.5 font-sans font-semibold">
                          Warehouse Source Record (Raw)
                        </div>
                        <pre className="text-slate-300 text-[11px] overflow-x-auto">
                          {JSON.stringify(diff.sourceRaw, null, 2)}
                        </pre>
                      </div>

                      <div className="bg-slate-900/80 border border-slate-800 rounded p-3">
                        <div className="text-[11px] text-cyan-400 mb-1.5 font-sans font-semibold flex items-center justify-between">
                          <span>Destination Payload (After Transforms)</span>
                          <span className="text-[10px] text-slate-400 uppercase">{destination.name}</span>
                        </div>
                        <pre className="text-cyan-200 text-[11px] overflow-x-auto">
                          {JSON.stringify(diff.transformedPayload, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: RUN HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">Execution History & Detailed Logs</h3>
                  <p className="text-xs text-slate-400">
                    Comprehensive trace logs, records delivered, API response codes, and throughput
                  </p>
                </div>
              </div>

              {syncRuns.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  No historical sync runs logged yet. Click "Run Sync Now" above to trigger a run!
                </div>
              ) : (
                <div className="space-y-4">
                  {syncRuns.map((run) => (
                    <div
                      key={run.id}
                      className="border border-slate-800 bg-slate-950/60 rounded-xl p-4 space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                        <div className="flex items-center gap-3">
                          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                          <span className="text-xs font-mono font-semibold text-white">
                            Run ID: {run.id}
                          </span>
                          <span className="text-xs text-slate-400">·</span>
                          <span className="text-xs text-slate-400">{run.startedAt}</span>
                        </div>
                        <div className="flex items-center gap-3 text-xs font-mono">
                          <span className="text-slate-300">Read: {run.recordsRead}</span>
                          <span className="text-cyan-400">+{run.recordsAdded} adds</span>
                          <span className="text-indigo-400">~{run.recordsUpdated} updates</span>
                          <span className="text-slate-400">Duration: {run.durationSec}s</span>
                        </div>
                      </div>

                      {/* Log Lines */}
                      <div className="bg-slate-950 border border-slate-900 rounded-lg p-3 font-mono text-[11px] space-y-1 max-h-48 overflow-y-auto">
                        {run.logs.map((log, lIdx) => (
                          <div key={lIdx} className="flex items-start gap-2">
                            <span className="text-slate-500 shrink-0">{log.timestamp}</span>
                            <span
                              className={`shrink-0 uppercase font-semibold ${
                                log.level === 'error'
                                  ? 'text-rose-400'
                                  : log.level === 'warn'
                                  ? 'text-amber-400'
                                  : 'text-indigo-400'
                              }`}
                            >
                              [{log.level}]
                            </span>
                            <span className="text-slate-300">{log.message}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SCHEDULE & TRIGGERS */}
          {activeTab === 'config' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Execution Frequency & Triggers</h3>
                <p className="text-xs text-slate-400">Configure how and when this reverse ETL sync runs</p>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-medium text-slate-300 block">Trigger Schedule</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-left text-xs transition-colors ${
                      sync.schedule.type === 'hourly'
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-semibold text-slate-200">Hourly Interval</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Runs every {sync.schedule.intervalMinutes || 60} mins</div>
                  </button>

                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-left text-xs transition-colors ${
                      sync.schedule.type === 'daily'
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-semibold text-slate-200">Daily Schedule</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Runs at 04:00 UTC</div>
                  </button>

                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-left text-xs transition-colors ${
                      sync.schedule.type === 'dbt_cloud_webhook'
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-semibold text-slate-200">dbt Cloud Webhook</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Runs when dbt job completes</div>
                  </button>
                </div>
              </div>

              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                <div className="text-xs font-semibold text-slate-300">Webhook Trigger URL</div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`https://api.vectorsync.io/v1/syncs/${sync.id}/trigger?token=vs_sec_91820491`}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 font-mono text-[11px] text-slate-300"
                  />
                  <button
                    onClick={() => alert('Webhook trigger URL copied to clipboard!')}
                    className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded transition-colors whitespace-nowrap"
                  >
                    Copy
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Trigger this sync instantly from GitHub Actions, Airflow, Dagster, or Prefect pipelines via POST request.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
