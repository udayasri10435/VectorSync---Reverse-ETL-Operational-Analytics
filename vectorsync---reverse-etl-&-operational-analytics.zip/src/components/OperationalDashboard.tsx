import React from 'react';
import {
  SyncConfig,
  SyncRunLog,
  Destination,
  SchemaDriftAlert,
  WarehouseSource,
} from '../types/reverse-etl';
import {
  Activity,
  ArrowUpRight,
  CheckCircle2,
  Clock,
  Database,
  ExternalLink,
  Layers,
  Play,
  RotateCw,
  Send,
  ShieldAlert,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';
import { NavigationTab } from './Header';

interface OperationalDashboardProps {
  syncs: SyncConfig[];
  runs: SyncRunLog[];
  destinations: Destination[];
  warehouses: WarehouseSource[];
  driftAlerts: SchemaDriftAlert[];
  onTriggerSync: (sync: SyncConfig) => void;
  onOpenSyncDetail: (sync: SyncConfig) => void;
  onNavigateTab: (tab: NavigationTab) => void;
  onOpenCreateSync: () => void;
}

export const OperationalDashboard: React.FC<OperationalDashboardProps> = ({
  syncs,
  runs,
  destinations,
  warehouses,
  driftAlerts,
  onTriggerSync,
  onOpenSyncDetail,
  onNavigateTab,
  onOpenCreateSync,
}) => {
  const unresolvedDrifts = driftAlerts.filter((d) => d.status === 'unresolved');
  const healthySyncsCount = syncs.filter((s) => s.status === 'healthy').length;

  const totalMonthlyRecords = syncs.reduce((acc, curr) => acc + curr.totalSyncedCount, 2454000);

  // Simulated 12-hour hourly sync volume breakdown
  const hourlySyncVolume = [
    { hour: '02:00', records: 18400, adds: 420 },
    { hour: '04:00', records: 45200, adds: 1200 },
    { hour: '06:00', records: 12400, adds: 180 },
    { hour: '08:00', records: 64100, adds: 2450 },
    { hour: '10:00', records: 89000, adds: 3820 },
    { hour: '12:00', records: 112000, adds: 5410 },
    { hour: '14:00', records: 98400, adds: 4120 },
    { hour: '16:00', records: 142000, adds: 6890 },
    { hour: '18:00', records: 128000, adds: 5120 },
    { hour: '20:00', records: 82000, adds: 2900 },
    { hour: '22:00', records: 54000, adds: 1400 },
    { hour: 'Now', records: 96000, adds: 3900 },
  ];

  const maxVolume = Math.max(...hourlySyncVolume.map((h) => h.records));

  return (
    <div className="space-y-6">
      {/* Schema Drift Alert Banner if active */}
      {unresolvedDrifts.length > 0 && (
        <div className="bg-amber-950/40 border border-amber-800/60 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-slate-200">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0 text-amber-400 mt-0.5 sm:mt-0">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-amber-200">
                Schema Drift Detected ({unresolvedDrifts.length} alert)
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Destination field type mismatch in <span className="font-mono text-amber-300">{unresolvedDrifts[0].syncName}</span>. Auto-remap recommended to avoid failed deliveries.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('drift')}
            className="px-3 py-1.5 text-xs font-semibold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto shrink-0"
          >
            Review & Auto-Remap
          </button>
        </div>
      )}

      {/* Top Operational Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>30-Day Operational Volume</span>
            <Database className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-white tabular-nums">
              {totalMonthlyRecords.toLocaleString()}
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
              <span className="text-emerald-400 font-medium font-mono">+18.4%</span>
              <span>vs previous 30 days</span>
            </div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Sync Success Reliability</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-emerald-400 tabular-nums">
              99.98%
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
              <span>2 quarantined records in DLQ</span>
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Active Sync Pipelines</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-white tabular-nums">
              {syncs.length} <span className="text-sm font-normal text-slate-400">active</span>
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
              <span className="text-emerald-400">{healthySyncsCount} healthy</span>
              <span>·</span>
              <span className="text-amber-400">{unresolvedDrifts.length} drift</span>
            </div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Avg Warehouse Latency</span>
            <Activity className="w-4 h-4 text-purple-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-white tabular-nums">
              41ms <span className="text-xs font-normal text-slate-400">(p95: 58ms)</span>
            </div>
            <div className="text-xs text-slate-400 mt-1">
              <span>Diff engine zero-copy cache active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sync Throughput Over Time Chart */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">
              Operational Throughput (Records Delivered to Destinations)
            </h2>
            <p className="text-xs text-slate-400">
              Aggregated hourly record delivery via Salesforce Bulk v2, HubSpot Batch API, and Google Ads UserDataService
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-sm bg-indigo-500"></div>
              <span>Total Synced</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-sm bg-cyan-400"></div>
              <span>Net New Added</span>
            </div>
          </div>
        </div>

        {/* SVG Bar Chart with Tabular Numerals */}
        <div className="h-44 flex items-end gap-2 pt-6">
          {hourlySyncVolume.map((item, idx) => {
            const heightPercent = Math.max(12, Math.round((item.records / maxVolume) * 100));
            const addsPercent = Math.max(4, Math.round((item.adds / item.records) * 100));

            return (
              <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                {/* Tooltip on hover */}
                <div className="absolute -top-12 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none bg-slate-950 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono whitespace-nowrap shadow-lg z-20">
                  <div>{item.records.toLocaleString()} records</div>
                  <div className="text-cyan-400">{item.adds.toLocaleString()} new inserts</div>
                </div>

                {/* Stacked bar */}
                <div
                  className="w-full rounded-t transition-all bg-indigo-600/80 group-hover:bg-indigo-500 relative overflow-hidden"
                  style={{ height: `${heightPercent}%` }}
                >
                  <div
                    className="w-full bg-cyan-400/90 absolute bottom-0 left-0 transition-all"
                    style={{ height: `${addsPercent}%` }}
                  />
                </div>
                <span className="text-[10px] font-mono text-slate-500 mt-2">{item.hour}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Two Column Layout: Active Syncs & Destination Quotas */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active Syncs with quick run */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200">Configured Reverse ETL Syncs</h2>
            <button
              onClick={() => onNavigateTab('syncs')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-medium inline-flex items-center gap-1"
            >
              <span>View all syncs ({syncs.length})</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {syncs.map((sync) => {
              const dest = destinations.find((d) => d.id === sync.destinationId);
              return (
                <div
                  key={sync.id}
                  className="bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-slate-700/90 rounded-xl p-4 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div
                    className="space-y-1.5 cursor-pointer flex-1"
                    onClick={() => onOpenSyncDetail(sync)}
                  >
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-white hover:text-indigo-300 transition-colors">
                        {sync.name}
                      </span>
                      {sync.status === 'drift_detected' ? (
                        <span className="text-xs font-mono text-amber-400 bg-amber-950/70 border border-amber-800/60 px-2 py-0.5 rounded">
                          Drift Detected
                        </span>
                      ) : (
                        <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                          Healthy
                        </span>
                      )}
                      <span className="text-xs font-mono text-slate-400 uppercase bg-slate-800/80 px-1.5 py-0.5 rounded">
                        {sync.syncMode}
                      </span>
                    </div>

                    <div className="text-xs text-slate-400 flex items-center gap-2 flex-wrap">
                      <span>Dest: <strong className="text-slate-300 font-medium">{dest?.name || sync.destinationId}</strong> ({sync.destinationObject})</span>
                      <span>·</span>
                      <span>Key: <code className="text-indigo-300 font-mono">{sync.sourceIdentifier}</code></span>
                      <span>·</span>
                      <span>Last run: <span className="text-slate-300">{sync.lastRunAt || 'Never'}</span></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onOpenSyncDetail(sync)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700/80 rounded-lg transition-colors"
                    >
                      Configure
                    </button>
                    <button
                      onClick={() => onTriggerSync(sync)}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-indigo-600/30"
                    >
                      <Play className="w-3 h-3 fill-white" />
                      <span>Run Now</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Destination API Health & Rate Limits */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200">Destination API Quotas</h2>
            <button
              onClick={() => onNavigateTab('destinations')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-medium inline-flex items-center gap-1"
            >
              <span>Manage</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 space-y-4">
            {destinations.slice(0, 4).map((dest) => {
              const remaining = dest.apiCallsRemaining;
              const limit = dest.apiCallsLimit;
              const usedPercent = Math.round(((limit - remaining) / limit) * 100);

              return (
                <div key={dest.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-200">{dest.name}</span>
                    <span className="font-mono text-slate-400 tabular-nums">
                      {remaining.toLocaleString()} left
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        usedPercent > 80
                          ? 'bg-rose-500'
                          : usedPercent > 50
                          ? 'bg-amber-400'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.max(4, usedPercent)}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                    <span>{usedPercent}% quota used today</span>
                    <span>Reset: {dest.resetTime}</span>
                  </div>
                </div>
              );
            })}

            <div className="pt-2 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
              <span>Automatic API rate-limit throttling</span>
              <span className="text-emerald-400 font-mono">Active (Backoff x2)</span>
            </div>
          </div>

          {/* Quick Create CTA Card */}
          <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900/60 to-slate-900/40 border border-indigo-900/50 rounded-xl p-4 space-y-2">
            <h3 className="text-sm font-semibold text-indigo-200">Connect a New Destination</h3>
            <p className="text-xs text-slate-300">
              Seamlessly sync warehouse audiences into Meta Ads, Braze, Zendesk, or custom webhook endpoints.
            </p>
            <button
              onClick={onOpenCreateSync}
              className="mt-2 w-full py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-sm"
            >
              + Create New Reverse ETL Sync
            </button>
          </div>
        </div>
      </div>

      {/* Recent Sync Executions Table */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">Recent Sync Executions</h2>
            <p className="text-xs text-slate-400">Audit logs with records read, updated, and duration</p>
          </div>
          <span className="text-xs font-mono text-slate-500">Live polling: 5s</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 text-slate-400 font-medium border-b border-slate-800">
              <tr>
                <th className="px-5 py-2.5">Sync Pipeline</th>
                <th className="px-5 py-2.5">Status</th>
                <th className="px-5 py-2.5 font-mono text-right">Read</th>
                <th className="px-5 py-2.5 font-mono text-right">Added</th>
                <th className="px-5 py-2.5 font-mono text-right">Updated</th>
                <th className="px-5 py-2.5 font-mono text-right">Failed</th>
                <th className="px-5 py-2.5 font-mono text-right">Duration</th>
                <th className="px-5 py-2.5 text-right">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {runs.map((run) => (
                <tr key={run.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="px-5 py-3 font-medium text-slate-200 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span>{run.syncName}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded">
                      Completed
                    </span>
                  </td>
                  <td className="px-5 py-3 font-mono text-right text-slate-300 tabular-nums">
                    {run.recordsRead.toLocaleString()}
                  </td>
                  <td className="px-5 py-3 font-mono text-right text-cyan-400 tabular-nums font-medium">
                    +{run.recordsAdded.toLocaleString()}
                  </td>
                  <td className="px-5 py-3 font-mono text-right text-indigo-300 tabular-nums font-medium">
                    {run.recordsUpdated.toLocaleString()}
                  </td>
                  <td className="px-5 py-3 font-mono text-right tabular-nums">
                    {run.recordsFailed > 0 ? (
                      <span className="text-rose-400 font-semibold">{run.recordsFailed}</span>
                    ) : (
                      <span className="text-slate-500">0</span>
                    )}
                  </td>
                  <td className="px-5 py-3 font-mono text-right text-slate-400 tabular-nums">
                    {run.durationSec}s
                  </td>
                  <td className="px-5 py-3 text-right text-slate-500 font-mono">
                    {run.startedAt}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
