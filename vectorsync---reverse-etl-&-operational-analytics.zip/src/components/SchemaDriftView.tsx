import React from 'react';
import { SchemaDriftAlert, SyncConfig } from '../types/reverse-etl';
import {
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RotateCw,
  RefreshCw,
} from 'lucide-react';

interface SchemaDriftViewProps {
  driftAlerts: SchemaDriftAlert[];
  syncs: SyncConfig[];
  onAutoRemap: (syncId: string) => void;
  onDismissAlert: (alertId: string) => void;
}

export const SchemaDriftView: React.FC<SchemaDriftViewProps> = ({
  driftAlerts,
  syncs,
  onAutoRemap,
  onDismissAlert,
}) => {
  const unresolvedAlerts = driftAlerts.filter((a) => a.status === 'unresolved');
  const resolvedAlerts = driftAlerts.filter((a) => a.status === 'resolved');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-base font-bold text-white tracking-tight">Schema Drift & Quarantine Protection</h2>
        <p className="text-xs text-slate-400">
          Proactive monitoring that halts or repairs syncs when warehouse column schemas or destination API definitions drift
        </p>
      </div>

      {/* Active Unresolved Drifts */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <span>Active Drift Alerts</span>
          {unresolvedAlerts.length > 0 && (
            <span className="text-xs font-mono text-amber-400 bg-amber-950/80 border border-amber-800/60 px-2 py-0.5 rounded">
              {unresolvedAlerts.length} Unresolved
            </span>
          )}
        </h3>

        {unresolvedAlerts.length === 0 ? (
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-8 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h4 className="text-sm font-semibold text-slate-200">No Schema Drift Detected</h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              All active warehouse models match their downstream destination schemas with 100% integrity.
            </p>
          </div>
        ) : (
          unresolvedAlerts.map((alert) => (
            <div
              key={alert.id}
              className="bg-amber-950/20 border border-amber-800/60 rounded-xl p-5 space-y-4 text-xs"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-amber-200">{alert.syncName}</h4>
                    <p className="text-xs text-slate-400">
                      Detected: <span className="text-slate-300">{alert.detectedAt}</span> · Issue:{' '}
                      <span className="text-amber-300 font-medium">Type Mismatch Drift</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onDismissAlert(alert.id)}
                    className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors"
                  >
                    Dismiss
                  </button>
                  <button
                    onClick={() => onAutoRemap(alert.syncId)}
                    className="px-3.5 py-1.5 text-xs font-semibold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-amber-400/20"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-Remap & Fix</span>
                  </button>
                </div>
              </div>

              {/* Diff Inspection Box */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-4 font-mono space-y-2">
                <div className="text-slate-400">
                  Affected Column:{' '}
                  <strong className="text-white font-semibold">{alert.columnName}</strong>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] pt-1">
                  <div className="bg-slate-900 border border-slate-800 rounded p-2.5">
                    <div className="text-slate-500 mb-1">Expected Type (Original):</div>
                    <div className="text-emerald-400">{alert.expected}</div>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 rounded p-2.5">
                    <div className="text-slate-500 mb-1">Current Live Type (Destination):</div>
                    <div className="text-amber-400">{alert.actual}</div>
                  </div>
                </div>
              </div>

              <div className="text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span>
                  Remediation: Click <strong>Auto-Remap</strong> to apply in-flight type-casting so future batches succeed without data loss.
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Resolved Drifts Log */}
      {resolvedAlerts.length > 0 && (
        <div className="space-y-3 pt-4 border-t border-slate-800">
          <h3 className="text-sm font-semibold text-slate-400">Recently Resolved Drift Events</h3>
          <div className="space-y-2">
            {resolvedAlerts.map((alert) => (
              <div
                key={alert.id}
                className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <div>
                    <div className="font-semibold text-slate-200">{alert.syncName}</div>
                    <div className="text-slate-400 font-mono text-[11px]">
                      Column <span className="text-slate-300">{alert.columnName}</span> auto-remapped with type casting.
                    </div>
                  </div>
                </div>
                <span className="text-emerald-400 font-mono text-[11px] bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded">
                  Resolved
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
