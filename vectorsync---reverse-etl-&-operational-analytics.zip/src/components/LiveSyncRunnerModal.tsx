import React, { useState, useEffect } from 'react';
import { SyncConfig, SyncRunLog } from '../types/reverse-etl';
import {
  Play,
  CheckCircle2,
  X,
  AlertTriangle,
  RotateCw,
  Terminal,
  Database,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface LiveSyncRunnerModalProps {
  sync: SyncConfig;
  isDryRun: boolean;
  onClose: () => void;
  onRunFinished: (newRun: SyncRunLog) => void;
}

export const LiveSyncRunnerModal: React.FC<LiveSyncRunnerModalProps> = ({
  sync,
  isDryRun,
  onClose,
  onRunFinished,
}) => {
  const [currentPhase, setCurrentPhase] = useState<
    'extract' | 'diff' | 'transform' | 'dispatch' | 'complete'
  >('extract');
  const [progressPercent, setProgressPercent] = useState(15);
  const [stats, setStats] = useState({
    read: 0,
    added: 0,
    updated: 0,
    unchanged: 0,
    failed: 0,
  });

  const [logs, setLogs] = useState<{ timestamp: string; level: 'info' | 'warn' | 'error'; message: string }[]>([
    {
      timestamp: '00:00.100',
      level: 'info',
      message: `Initiating ${isDryRun ? 'DRY-RUN' : 'LIVE'} sync execution: ${sync.name}`,
    },
  ]);

  const targetTotal = Math.max(120, sync.totalSyncedCount || 480);

  useEffect(() => {
    // Multi-phase execution simulation
    const timer1 = setTimeout(() => {
      setCurrentPhase('diff');
      setProgressPercent(35);
      setStats((prev) => ({ ...prev, read: targetTotal }));
      setLogs((prev) => [
        ...prev,
        {
          timestamp: '00:00.650',
          level: 'info',
          message: `Connected to warehouse source. Extracted ${targetTotal.toLocaleString()} rows in 420ms.`,
        },
        {
          timestamp: '00:00.920',
          level: 'info',
          message: `Diff Engine: Calculating MD5/SHA checksums against previous state snapshot...`,
        },
      ]);
    }, 700);

    const timer2 = setTimeout(() => {
      setCurrentPhase('transform');
      setProgressPercent(65);
      const calculatedAdds = Math.floor(targetTotal * 0.05) + 3;
      const calculatedUpdates = Math.floor(targetTotal * 0.15) + 12;
      const calculatedUnchanged = targetTotal - calculatedAdds - calculatedUpdates;

      setStats({
        read: targetTotal,
        added: calculatedAdds,
        updated: calculatedUpdates,
        unchanged: calculatedUnchanged,
        failed: 0,
      });

      setLogs((prev) => [
        ...prev,
        {
          timestamp: '00:01.400',
          level: 'info',
          message: `Delta detected: ${calculatedAdds} new records, ${calculatedUpdates} modified records (${calculatedUnchanged} unchanged).`,
        },
        {
          timestamp: '00:01.750',
          level: 'info',
          message: `Applied ${sync.mappings.length} in-flight transformations (type conversions, lowercase, sanitization).`,
        },
      ]);
    }, 1500);

    const timer3 = setTimeout(() => {
      setCurrentPhase('dispatch');
      setProgressPercent(90);
      setLogs((prev) => [
        ...prev,
        {
          timestamp: '00:02.100',
          level: 'info',
          message: isDryRun
            ? `[Dry Run] Simulated batch delivery to destination endpoint. No external API mutations sent.`
            : `Transmitting batch 1/1 to destination API endpoint (Payload size: 284 KB).`,
        },
        {
          timestamp: '00:02.750',
          level: 'info',
          message: `Destination response received: HTTP 200 OK (Batch processed successfully in 340ms).`,
        },
      ]);
    }, 2400);

    const timer4 = setTimeout(() => {
      setCurrentPhase('complete');
      setProgressPercent(100);
      setLogs((prev) => [
        ...prev,
        {
          timestamp: '00:03.100',
          level: 'info',
          message: `Sync execution ${isDryRun ? 'dry-run completed' : 'finalized'}. Checkpoint committed to storage.`,
        },
      ]);

      const calculatedAdds = Math.floor(targetTotal * 0.05) + 3;
      const calculatedUpdates = Math.floor(targetTotal * 0.15) + 12;
      const calculatedUnchanged = targetTotal - calculatedAdds - calculatedUpdates;

      const newRun: SyncRunLog = {
        id: `run-${Date.now().toString().slice(-4)}`,
        syncId: sync.id,
        syncName: sync.name,
        startedAt: 'Just now',
        finishedAt: 'Just now',
        status: isDryRun ? 'dry_run_completed' : 'completed',
        isDryRun,
        durationSec: 3.1,
        recordsRead: targetTotal,
        recordsAdded: calculatedAdds,
        recordsUpdated: calculatedUpdates,
        recordsUnchanged: calculatedUnchanged,
        recordsFailed: 0,
        throughputPerSec: Math.round(targetTotal / 3.1),
        logs: [
          { timestamp: '14:32:00.100', level: 'info', message: 'Warehouse snapshot extracted.' },
          { timestamp: '14:32:01.400', level: 'info', message: 'State diff computed.' },
          { timestamp: '14:32:02.800', level: 'info', message: 'Delivered to destination API with HTTP 200 OK.' },
        ],
      };

      onRunFinished(newRun);
    }, 3200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl shadow-2xl flex flex-col overflow-hidden my-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <span
              className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                currentPhase === 'complete'
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  : 'bg-indigo-950 text-indigo-400 border border-indigo-800 animate-pulse'
              }`}
            >
              {currentPhase === 'complete' ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : (
                <RotateCw className="w-4 h-4 animate-spin" />
              )}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  {isDryRun ? 'Simulating Dry-Run' : 'Executing Reverse ETL Sync'}
                </h3>
                <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded">
                  {sync.syncMode}
                </span>
              </div>
              <p className="text-xs text-slate-400">{sync.name}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Phase indicator pipeline */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-900/40 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">
              Pipeline Stage:{' '}
              <strong className="text-white font-semibold uppercase">
                {currentPhase}
              </strong>
            </span>
            <span className="text-indigo-400 font-bold">{progressPercent}%</span>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                currentPhase === 'complete' ? 'bg-emerald-500' : 'bg-indigo-500'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Stepper pills */}
          <div className="grid grid-cols-4 gap-2 pt-1 text-[11px] font-medium text-slate-400 text-center">
            <div className={currentPhase !== 'extract' ? 'text-emerald-400' : 'text-indigo-300'}>
              1. Extract
            </div>
            <div className={['transform', 'dispatch', 'complete'].includes(currentPhase) ? 'text-emerald-400' : currentPhase === 'diff' ? 'text-indigo-300' : 'text-slate-600'}>
              2. Diff Engine
            </div>
            <div className={['dispatch', 'complete'].includes(currentPhase) ? 'text-emerald-400' : currentPhase === 'transform' ? 'text-indigo-300' : 'text-slate-600'}>
              3. Transform
            </div>
            <div className={currentPhase === 'complete' ? 'text-emerald-400' : currentPhase === 'dispatch' ? 'text-indigo-300' : 'text-slate-600'}>
              4. Deliver API
            </div>
          </div>
        </div>

        {/* Real-time Counter Stats */}
        <div className="px-6 py-4 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/60 border-b border-slate-800">
          <div className="p-2.5 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-[11px] text-slate-400">Records Scanned</div>
            <div className="text-lg font-bold font-mono text-white tabular-nums">
              {stats.read.toLocaleString()}
            </div>
          </div>

          <div className="p-2.5 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-[11px] text-slate-400">Net-New Added</div>
            <div className="text-lg font-bold font-mono text-cyan-400 tabular-nums">
              +{stats.added.toLocaleString()}
            </div>
          </div>

          <div className="p-2.5 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-[11px] text-slate-400">Modified / Updated</div>
            <div className="text-lg font-bold font-mono text-indigo-300 tabular-nums">
              ~{stats.updated.toLocaleString()}
            </div>
          </div>

          <div className="p-2.5 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-[11px] text-slate-400">Unchanged (Skipped)</div>
            <div className="text-lg font-bold font-mono text-slate-400 tabular-nums">
              {stats.unchanged.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Live Streaming Logs Terminal */}
        <div className="p-6 space-y-2 flex-1">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-300">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Real-Time Execution Logs</span>
            </div>
            <span className="font-mono text-[11px]">Stream active</span>
          </div>

          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 font-mono text-xs text-slate-300 h-52 overflow-y-auto space-y-1.5">
            {logs.map((log, idx) => (
              <div key={idx} className="flex items-start gap-2.5">
                <span className="text-slate-500 text-[11px] shrink-0 font-medium">
                  {log.timestamp}
                </span>
                <span
                  className={`text-[11px] font-semibold shrink-0 uppercase ${
                    log.level === 'error'
                      ? 'text-rose-400'
                      : log.level === 'warn'
                      ? 'text-amber-400'
                      : 'text-indigo-400'
                  }`}
                >
                  [{log.level}]
                </span>
                <span className="text-slate-300 leading-relaxed">{log.message}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="text-xs text-slate-400">
            {currentPhase === 'complete' ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Execution complete in 3.1 seconds (480 records/sec)</span>
              </span>
            ) : (
              <span>Syncing delta in background...</span>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            {currentPhase === 'complete' ? 'Done' : 'Dismiss to Background'}
          </button>
        </div>
      </div>
    </div>
  );
};
