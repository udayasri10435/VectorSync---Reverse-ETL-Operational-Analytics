import React, { useState } from 'react';
import { Destination, DestinationType } from '../types/reverse-etl';
import {
  Send,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Plus,
  Layers,
  ShieldCheck,
  Zap,
  Sliders,
  ExternalLink,
  X,
} from 'lucide-react';

interface DestinationsViewProps {
  destinations: Destination[];
  onAddDestination: (dest: Destination) => void;
}

export const DestinationsView: React.FC<DestinationsViewProps> = ({
  destinations,
  onAddDestination,
}) => {
  const [selectedDestId, setSelectedDestId] = useState<string>(destinations[0]?.id || '');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New Destination Form
  const [newDestName, setNewDestName] = useState('');
  const [newDestType, setNewDestType] = useState<DestinationType>('salesforce');
  const [newAccountName, setNewAccountName] = useState('');

  const selectedDest = destinations.find((d) => d.id === selectedDestId) || destinations[0];

  const handleSaveDestination = () => {
    const newDest: Destination = {
      id: `dest-${Date.now()}`,
      name: newDestName || `${newDestType.toUpperCase()} Destination`,
      type: newDestType,
      authType: 'oauth',
      accountName: newAccountName || 'Production Account',
      status: 'connected',
      apiCallsRemaining: 95000,
      apiCallsLimit: 100000,
      resetTime: 'In 24 hours',
      batchSize: 200,
      supportedObjects: [
        {
          id: 'standard_record',
          label: 'Standard Record',
          identifierFields: ['external_id', 'email'],
          fields: [
            { name: 'email', label: 'Email', type: 'string', required: true },
            { name: 'external_id', label: 'External ID', type: 'string', required: true },
            { name: 'custom_tag', label: 'Custom Tag', type: 'string', required: false },
          ],
        },
      ],
    };

    onAddDestination(newDest);
    setIsAddModalOpen(false);
    setSelectedDestId(newDest.id);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Downstream Destinations</h2>
          <p className="text-xs text-slate-400">
            Monitor API rate limits, authenticate CRMs and ad networks, and inspect supported schemas
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>Connect Destination</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left Column: Destinations List */}
        <div className="space-y-3">
          {destinations.map((dest) => {
            const usagePercent = Math.round(
              ((dest.apiCallsLimit - dest.apiCallsRemaining) / dest.apiCallsLimit) * 100
            );

            return (
              <div
                key={dest.id}
                onClick={() => setSelectedDestId(dest.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedDestId === dest.id
                    ? 'border-indigo-500 bg-indigo-950/40 text-white'
                    : 'border-slate-800/80 bg-slate-900/60 hover:bg-slate-900 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm font-semibold">{dest.name}</span>
                  <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                    {dest.type}
                  </span>
                </div>

                <div className="text-xs text-slate-400 truncate">{dest.accountName}</div>

                {/* API meter */}
                <div className="mt-3 pt-2 border-t border-slate-800/80 space-y-1">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>Rate limit remaining:</span>
                    <span className="text-slate-200 tabular-nums">
                      {dest.apiCallsRemaining.toLocaleString()}
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        usagePercent > 80 ? 'bg-rose-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.max(4, usagePercent)}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right 2 Columns: Destination Inspector */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-xl overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950/40">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">{selectedDest.name}</h3>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded">
                  Connected
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Account: <strong className="text-slate-200">{selectedDest.accountName}</strong> · Auth:{' '}
                <span className="uppercase text-slate-300 font-mono">{selectedDest.authType}</span>
              </p>
            </div>

            <div className="text-right text-xs">
              <div className="text-slate-400">Batch Size:</div>
              <div className="font-mono text-white font-semibold">
                {selectedDest.batchSize} records/call
              </div>
            </div>
          </div>

          {/* Quota Details Card */}
          <div className="p-5 space-y-5 flex-1">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
                <div className="text-xs text-slate-400">Daily API Calls Quota</div>
                <div className="text-lg font-bold font-mono text-white mt-1">
                  {selectedDest.apiCallsLimit.toLocaleString()}
                </div>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
                <div className="text-xs text-slate-400">Remaining Today</div>
                <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
                  {selectedDest.apiCallsRemaining.toLocaleString()}
                </div>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
                <div className="text-xs text-slate-400">Quota Reset Timer</div>
                <div className="text-sm font-semibold text-slate-200 mt-1.5">
                  {selectedDest.resetTime}
                </div>
              </div>
            </div>

            {/* Supported Objects & Schemas */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Supported Objects & Target Schema
                </h4>
                <span className="text-xs font-mono text-slate-500">
                  {selectedDest.supportedObjects.length} objects available
                </span>
              </div>

              <div className="space-y-3">
                {selectedDest.supportedObjects.map((obj) => (
                  <div
                    key={obj.id}
                    className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-white">{obj.label}</span>
                        <code className="text-xs font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 px-1.5 py-0.2 rounded">
                          {obj.id}
                        </code>
                      </div>
                      <span className="text-xs font-mono text-slate-400">
                        {obj.fields.length} writeable fields
                      </span>
                    </div>

                    <div className="text-xs text-slate-400">
                      Primary Match Identifiers: <code className="text-indigo-300 font-mono">{obj.identifierFields.join(', ')}</code>
                    </div>

                    {/* Field tags */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {obj.fields.map((f) => (
                        <span
                          key={f.name}
                          className="text-[11px] font-mono bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-slate-300"
                        >
                          {f.name}{' '}
                          {f.required && <span className="text-rose-400 text-[10px]">*</span>}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Destination Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Connect Destination</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1">Destination Service</label>
                <select
                  value={newDestType}
                  onChange={(e) => setNewDestType(e.target.value as DestinationType)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white"
                >
                  <option value="salesforce">Salesforce CRM</option>
                  <option value="hubspot">HubSpot CRM</option>
                  <option value="google_ads">Google Ads</option>
                  <option value="meta_ads">Meta Ads (Facebook Audiences)</option>
                  <option value="braze">Braze Customer Engagement</option>
                  <option value="zendesk">Zendesk Support</option>
                  <option value="slack">Slack Internal Webhooks</option>
                  <option value="webhook">Custom HTTPS Webhook</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Display Label</label>
                <input
                  type="text"
                  placeholder="e.g. Salesforce Staging Org"
                  value={newDestName}
                  onChange={(e) => setNewDestName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Account Identifier or Domain</label>
                <input
                  type="text"
                  placeholder="e.g. acme-staging.my.salesforce.com"
                  value={newAccountName}
                  onChange={(e) => setNewAccountName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white font-mono"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="px-3.5 py-1.5 text-xs text-slate-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveDestination}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm"
              >
                Authorize & Connect
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
