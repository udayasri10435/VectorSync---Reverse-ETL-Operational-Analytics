import React, { useState } from 'react';
import { QuarantinedRecord } from '../types/reverse-etl';
import {
  ShieldAlert,
  RotateCw,
  CheckCircle2,
  Trash2,
  ExternalLink,
  Code,
  Search,
} from 'lucide-react';

interface QuarantineViewProps {
  quarantinedRecords: QuarantinedRecord[];
  onRetryRecord: (recordId: string) => void;
  onIgnoreRecord: (recordId: string) => void;
}

export const QuarantineView: React.FC<QuarantineViewProps> = ({
  quarantinedRecords,
  onRetryRecord,
  onIgnoreRecord,
}) => {
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const activeQuarantine = quarantinedRecords.filter(
    (q) => q.retryStatus === 'pending' || q.retryStatus === 'retrying'
  );

  const handleRetry = (id: string) => {
    setRetryingId(id);
    setTimeout(() => {
      onRetryRecord(id);
      setRetryingId(null);
    }, 700);
  };

  const filtered = activeQuarantine.filter((q) =>
    q.recordIdentifier.toLowerCase().includes(searchQuery.toLowerCase()) ||
    q.errorReason.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Dead Letter Queue (DLQ) & Quarantine</h2>
          <p className="text-xs text-slate-400">
            Records rejected by destination APIs are isolated here with full error traces for inspection and replay
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-rose-400 bg-rose-950/80 border border-rose-800/60 px-2.5 py-1 rounded">
            {activeQuarantine.length} Quarantined Rows
          </span>
        </div>
      </div>

      {/* Search bar */}
      <div className="max-w-md">
        <input
          type="text"
          placeholder="Filter quarantined rows by identifier or error message..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
        />
      </div>

      {/* Quarantined Records List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-10 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h4 className="text-sm font-semibold text-slate-200">DLQ is Clear</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              No rejected records in quarantine. All sync batches delivered cleanly without destination API errors.
            </p>
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-5 space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-semibold text-rose-300">
                      Record: {item.recordIdentifier}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">· {item.occurredAt}</span>
                  </div>
                  <div className="text-xs text-rose-400 font-medium">{item.errorReason}</div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onIgnoreRecord(item.id)}
                    className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition-colors"
                  >
                    Dismiss
                  </button>
                  <button
                    onClick={() => handleRetry(item.id)}
                    disabled={retryingId === item.id}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-indigo-600/30 disabled:opacity-50"
                  >
                    <RotateCw className={`w-3.5 h-3.5 ${retryingId === item.id ? 'animate-spin' : ''}`} />
                    <span>{retryingId === item.id ? 'Retrying...' : 'Replay to API'}</span>
                  </button>
                </div>
              </div>

              {/* Payload trace */}
              <div className="bg-slate-950 border border-slate-900 rounded-lg p-3 font-mono text-[11px] overflow-x-auto">
                <div className="text-slate-500 mb-1 font-sans">Rejected Payload:</div>
                <pre className="text-slate-300">{JSON.stringify(item.rawPayload, null, 2)}</pre>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
