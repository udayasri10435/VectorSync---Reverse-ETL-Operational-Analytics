import React from 'react';
import { Play, Plus, RefreshCw, Zap, ShieldAlert } from 'lucide-react';

export type NavigationTab =
  | 'overview'
  | 'syncs'
  | 'models'
  | 'sources'
  | 'destinations'
  | 'drift'
  | 'quarantine';

interface HeaderProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  onOpenCreateSync: () => void;
  driftCount: number;
  quarantineCount: number;
  onQuickRunAll: () => void;
  isGlobalSyncing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenCreateSync,
  driftCount,
  quarantineCount,
  onQuickRunAll,
  isGlobalSyncing,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark as required by Top Bar Contract */}
        <div className="flex items-center gap-3">
          <a
            href="#overview"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('overview');
            }}
            className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-white hover:text-indigo-400 transition-colors shrink-0"
          >
            <span className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 flex items-center justify-center text-white shadow-sm shadow-indigo-500/20">
              <Zap className="w-4 h-4 fill-white text-white" />
            </span>
            <span className="font-semibold tracking-tight text-slate-100">VectorSync</span>
          </a>
          <span className="text-xs text-slate-500 hidden sm:inline-block">·</span>
          <span className="text-xs text-slate-400 font-medium hidden sm:inline-block">Acme Production DW</span>
        </div>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-1.5 text-sm font-medium">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'overview'
                ? 'text-white bg-slate-800/90 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('syncs')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'syncs'
                ? 'text-white bg-slate-800/90 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Syncs
          </button>
          <button
            onClick={() => setActiveTab('models')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'models'
                ? 'text-white bg-slate-800/90 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Models & SQL
          </button>
          <button
            onClick={() => setActiveTab('sources')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'sources'
                ? 'text-white bg-slate-800/90 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Warehouses
          </button>
          <button
            onClick={() => setActiveTab('destinations')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'destinations'
                ? 'text-white bg-slate-800/90 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Destinations
          </button>
          <button
            onClick={() => setActiveTab('drift')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'drift'
                ? 'text-white bg-slate-800/90 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <span>Schema Drift</span>
            {driftCount > 0 && (
              <span className="text-[11px] font-mono text-amber-400 bg-amber-950/80 border border-amber-800/60 px-1.5 py-0.2 rounded">
                {driftCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('quarantine')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'quarantine'
                ? 'text-white bg-slate-800/90 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <span>Audit & DLQ</span>
            {quarantineCount > 0 && (
              <span className="text-[11px] font-mono text-rose-400 bg-rose-950/80 border border-rose-800/60 px-1.5 py-0.2 rounded">
                {quarantineCount}
              </span>
            )}
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onQuickRunAll}
            disabled={isGlobalSyncing}
            className="hidden md:inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-colors disabled:opacity-50 whitespace-nowrap"
            title="Trigger diff check across all enabled syncs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGlobalSyncing ? 'animate-spin text-indigo-400' : 'text-slate-400'}`} />
            <span>{isGlobalSyncing ? 'Syncing...' : 'Sync All'}</span>
          </button>

          <button
            onClick={onOpenCreateSync}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm shadow-indigo-600/30 transition-all hover:shadow-indigo-600/50 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>New Sync</span>
          </button>
        </div>
      </div>

      {/* Mobile nav bar fallback */}
      <div className="flex lg:hidden overflow-x-auto gap-2 pt-2.5 pb-0.5 border-t border-slate-800/60 mt-2 text-xs scrollbar-none">
        {(
          [
            ['overview', 'Overview'],
            ['syncs', 'Syncs'],
            ['models', 'Models & SQL'],
            ['sources', 'Warehouses'],
            ['destinations', 'Destinations'],
            ['drift', `Drift ${driftCount > 0 ? `(${driftCount})` : ''}`],
            ['quarantine', `Audit DLQ ${quarantineCount > 0 ? `(${quarantineCount})` : ''}`],
          ] as [NavigationTab, string][]
        ).map(([tabKey, label]) => (
          <button
            key={tabKey}
            onClick={() => setActiveTab(tabKey)}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium transition-colors ${
              activeTab === tabKey ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>
    </header>
  );
};
