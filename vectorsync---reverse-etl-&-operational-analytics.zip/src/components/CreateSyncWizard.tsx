import React, { useState } from 'react';
import {
  DataModel,
  Destination,
  SyncConfig,
  SyncMode,
  FieldMapping,
  TransformType,
} from '../types/reverse-etl';
import {
  X,
  Check,
  ArrowRight,
  Database,
  Layers,
  Sparkles,
  Plus,
  Trash2,
  Clock,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface CreateSyncWizardProps {
  models: DataModel[];
  destinations: Destination[];
  onClose: () => void;
  onCreateSync: (newSync: SyncConfig) => void;
}

export const CreateSyncWizard: React.FC<CreateSyncWizardProps> = ({
  models,
  destinations,
  onClose,
  onCreateSync,
}) => {
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Form states
  const [selectedModelId, setSelectedModelId] = useState<string>(models[0]?.id || '');
  const [selectedDestId, setSelectedDestId] = useState<string>(destinations[0]?.id || '');
  const [selectedDestObject, setSelectedDestObject] = useState<string>('');
  const [syncName, setSyncName] = useState<string>('');
  const [syncDescription, setSyncDescription] = useState<string>('');
  const [syncMode, setSyncMode] = useState<SyncMode>('upsert');
  const [sourceIdentifier, setSourceIdentifier] = useState<string>('');
  const [destinationIdentifier, setDestinationIdentifier] = useState<string>('');
  const [mappings, setMappings] = useState<FieldMapping[]>([]);
  const [scheduleType, setScheduleType] = useState<'hourly' | 'daily' | 'dbt_cloud_webhook' | 'manual'>('hourly');

  const selectedModel = models.find((m) => m.id === selectedModelId) || models[0];
  const selectedDest = destinations.find((d) => d.id === selectedDestId) || destinations[0];

  // Set initial destination object when destination changes
  React.useEffect(() => {
    if (selectedDest && selectedDest.supportedObjects.length > 0) {
      const firstObj = selectedDest.supportedObjects[0];
      setSelectedDestObject(firstObj.id);
      setDestinationIdentifier(firstObj.identifierFields[0] || '');
    }
  }, [selectedDestId]);

  // Set initial source identifier when model changes
  React.useEffect(() => {
    if (selectedModel) {
      setSourceIdentifier(selectedModel.primaryKey);
      setSyncName(`${selectedModel.name} to ${selectedDest.name}`);
    }
  }, [selectedModelId, selectedDestId]);

  const destObject = selectedDest?.supportedObjects.find((o) => o.id === selectedDestObject);
  const destFields = destObject?.fields || [];
  const sourceColumns = selectedModel?.columns || [];

  // Auto-map matching fields
  const handleAutoMap = () => {
    const newMappings: FieldMapping[] = [];

    // Add identifier mapping first
    newMappings.push({
      id: `map_id_${Date.now()}`,
      sourceColumn: sourceIdentifier || sourceColumns[0]?.name || '',
      destinationField: destinationIdentifier || destFields[0]?.name || '',
      transform: 'direct',
      isIdentifier: true,
    });

    // Match remaining columns
    sourceColumns.forEach((col) => {
      if (col.name === sourceIdentifier) return;

      const cleanColName = col.name.toLowerCase().replace(/[^a-z0-9]/g, '');
      const match = destFields.find((f) => {
        const cleanFieldName = f.name.toLowerCase().replace(/[^a-z0-9]/g, '');
        return cleanFieldName === cleanColName || cleanFieldName.includes(cleanColName);
      });

      if (match && !newMappings.some((m) => m.destinationField === match.name)) {
        newMappings.push({
          id: `map_${col.name}_${Date.now()}`,
          sourceColumn: col.name,
          destinationField: match.name,
          transform: col.name.includes('email') ? 'lowercase' : 'direct',
        });
      }
    });

    setMappings(newMappings);
  };

  const handleAddMappingRow = () => {
    const unmappedSource = sourceColumns.find(
      (sc) => !mappings.some((m) => m.sourceColumn === sc.name)
    );
    const unmappedDest = destFields.find(
      (df) => !mappings.some((m) => m.destinationField === df.name)
    );

    setMappings((prev) => [
      ...prev,
      {
        id: `map_${Date.now()}`,
        sourceColumn: unmappedSource ? unmappedSource.name : sourceColumns[0]?.name || '',
        destinationField: unmappedDest ? unmappedDest.name : destFields[0]?.name || '',
        transform: 'direct',
      },
    ]);
  };

  const handleRemoveMapping = (id: string) => {
    setMappings((prev) => prev.filter((m) => m.id !== id));
  };

  const handleUpdateMapping = (id: string, updates: Partial<FieldMapping>) => {
    setMappings((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updates } : m))
    );
  };

  const handleFinish = () => {
    const newSync: SyncConfig = {
      id: `sync-${Date.now()}`,
      name: syncName || `${selectedModel.name} to ${destObject?.label || selectedDestObject}`,
      description:
        syncDescription ||
        `Reverse ETL pipeline syncing ${selectedModel.name} from warehouse to ${selectedDest.name} (${selectedDestObject}).`,
      sourceModelId: selectedModel.id,
      destinationId: selectedDest.id,
      destinationObject: selectedDestObject,
      syncMode,
      sourceIdentifier: sourceIdentifier || selectedModel.primaryKey,
      destinationIdentifier: destinationIdentifier || destObject?.identifierFields[0] || 'id',
      mappings: mappings.length > 0 ? mappings : [
        {
          id: 'map_initial',
          sourceColumn: sourceIdentifier || selectedModel.primaryKey,
          destinationField: destinationIdentifier || 'id',
          transform: 'direct',
          isIdentifier: true,
        },
      ],
      schedule: {
        type: scheduleType,
        intervalMinutes: scheduleType === 'hourly' ? 60 : undefined,
      },
      status: 'healthy',
      enabled: true,
      totalSyncedCount: 0,
      lastRunAt: 'Never',
    };

    onCreateSync(newSync);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden my-auto">
        {/* Wizard Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">Create Reverse ETL Sync Pipeline</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Sync transformed warehouse data directly into business applications
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Stepper Bar */}
        <div className="px-6 py-3 border-b border-slate-800 bg-slate-900/40 flex items-center justify-between text-xs">
          {[
            { step: 1, label: '1. Source Model' },
            { step: 2, label: '2. Destination' },
            { step: 3, label: '3. Sync Mode & Key' },
            { step: 4, label: '4. Field Mappings' },
            { step: 5, label: '5. Schedule & Review' },
          ].map((item) => (
            <div
              key={item.step}
              className={`flex items-center gap-1.5 font-medium transition-colors ${
                currentStep === item.step
                  ? 'text-indigo-400 font-semibold'
                  : currentStep > item.step
                  ? 'text-emerald-400'
                  : 'text-slate-500'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-mono ${
                  currentStep === item.step
                    ? 'bg-indigo-600 text-white'
                    : currentStep > item.step
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {currentStep > item.step ? '✓' : item.step}
              </span>
              <span className="hidden sm:inline">{item.label}</span>
            </div>
          ))}
        </div>

        {/* Wizard Body Container */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* STEP 1: SELECT SOURCE MODEL */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Select Warehouse Source Model</h3>
                <p className="text-xs text-slate-400">Choose the compiled SQL, dbt model, or table view to extract data from</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {models.map((model) => (
                  <div
                    key={model.id}
                    onClick={() => setSelectedModelId(model.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedModelId === model.id
                        ? 'border-indigo-500 bg-indigo-950/30 shadow-sm'
                        : 'border-slate-800 bg-slate-950/40 hover:bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Database className="w-4 h-4 text-indigo-400" />
                        <span className="text-sm font-semibold text-white">{model.name}</span>
                      </div>
                      <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                        {model.type}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {model.description}
                    </p>

                    <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Primary Key: <strong className="text-slate-300 font-medium">{model.primaryKey}</strong></span>
                      <span>{model.rowCount.toLocaleString()} rows</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: SELECT DESTINATION */}
          {currentStep === 2 && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Select Destination & Object</h3>
                <p className="text-xs text-slate-400">Choose which CRM, ad platform, or marketing tool receives the sync</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {destinations.map((dest) => (
                  <div
                    key={dest.id}
                    onClick={() => setSelectedDestId(dest.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      selectedDestId === dest.id
                        ? 'border-indigo-500 bg-indigo-950/30'
                        : 'border-slate-800 bg-slate-950/40 hover:bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold text-white">{dest.name}</span>
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    </div>
                    <div className="text-xs text-slate-400">{dest.accountName}</div>
                    <div className="text-[11px] text-slate-500 font-mono mt-2">
                      {dest.apiCallsRemaining.toLocaleString()} API calls left today
                    </div>
                  </div>
                ))}
              </div>

              {/* Target Object Selector */}
              {selectedDest && (
                <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-3">
                  <label className="text-xs font-semibold text-slate-200 block">
                    Choose Destination Object in {selectedDest.name}
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {selectedDest.supportedObjects.map((obj) => (
                      <button
                        key={obj.id}
                        type="button"
                        onClick={() => {
                          setSelectedDestObject(obj.id);
                          setDestinationIdentifier(obj.identifierFields[0] || '');
                        }}
                        className={`p-2.5 rounded-lg border text-left text-xs transition-colors ${
                          selectedDestObject === obj.id
                            ? 'border-indigo-500 bg-indigo-950/50 text-white font-semibold'
                            : 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-850'
                        }`}
                      >
                        <div>{obj.label}</div>
                        <div className="text-[10px] text-slate-500 font-mono font-normal">
                          {obj.fields.length} available fields
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 3: SYNC MODE & KEY IDENTIFIER */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Sync Mode & Identifier Matching</h3>
                <p className="text-xs text-slate-400">
                  Select how records are synced and matched between the warehouse and the destination
                </p>
              </div>

              {/* Sync Mode Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 block">Sync Mode</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setSyncMode('upsert')}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-colors ${
                      syncMode === 'upsert'
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="text-sm font-semibold text-white">Upsert (Recommended)</div>
                    <p className="text-xs text-slate-400 mt-1">
                      Inserts new records if not present in the destination; updates existing records if values changed.
                    </p>
                  </div>

                  <div
                    onClick={() => setSyncMode('mirror')}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-colors ${
                      syncMode === 'mirror'
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="text-sm font-semibold text-white">Mirror (Full Sync)</div>
                    <p className="text-xs text-slate-400 mt-1">
                      Mirrors the exact state of warehouse query in the destination. Archives or deletes removed records.
                    </p>
                  </div>

                  <div
                    onClick={() => setSyncMode('insert')}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-colors ${
                      syncMode === 'insert'
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="text-sm font-semibold text-white">Insert Only</div>
                    <p className="text-xs text-slate-400 mt-1">
                      Appends new records as an event log or activity stream; never modifies existing rows.
                    </p>
                  </div>

                  <div
                    onClick={() => setSyncMode('update_only')}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-colors ${
                      syncMode === 'update_only'
                        ? 'border-indigo-500 bg-indigo-950/40 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="text-sm font-semibold text-white">Update Only</div>
                    <p className="text-xs text-slate-400 mt-1">
                      Updates records that already exist in destination; does not create new records.
                    </p>
                  </div>
                </div>
              </div>

              {/* Primary Key Identifier matching */}
              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-4">
                <div className="text-xs font-semibold text-slate-200">
                  Primary Key Identifier Matching
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 block mb-1.5">
                      Warehouse Unique Column ({selectedModel.name})
                    </label>
                    <select
                      value={sourceIdentifier}
                      onChange={(e) => setSourceIdentifier(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                    >
                      {sourceColumns.map((col) => (
                        <option key={col.name} value={col.name}>
                          {col.name} ({col.type})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 block mb-1.5">
                      Destination Match Field ({destObject?.label || selectedDestObject})
                    </label>
                    <select
                      value={destinationIdentifier}
                      onChange={(e) => setDestinationIdentifier(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-indigo-500"
                    >
                      {destObject?.identifierFields.map((field) => (
                        <option key={field} value={field}>
                          {field} (Identifier)
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: FIELD MAPPINGS & IN-FLIGHT TRANSFORMS */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">Field Mappings & Transformations</h3>
                  <p className="text-xs text-slate-400">Map columns and apply hashing, casing, and type-casting</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAutoMap}
                    className="px-3 py-1.5 text-xs font-semibold text-indigo-300 bg-indigo-950/80 hover:bg-indigo-900/80 border border-indigo-800/80 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Auto-Map Matching</span>
                  </button>
                  <button
                    onClick={handleAddMappingRow}
                    className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Field</span>
                  </button>
                </div>
              </div>

              {mappings.length === 0 ? (
                <div className="p-8 border border-dashed border-slate-800 rounded-xl text-center space-y-2">
                  <p className="text-xs text-slate-400">No field mappings configured yet.</p>
                  <button
                    onClick={handleAutoMap}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors inline-flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-Map Matching Columns</span>
                  </button>
                </div>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/40">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950/80 text-slate-400 font-medium border-b border-slate-800">
                      <tr>
                        <th className="px-4 py-2.5">Warehouse Column</th>
                        <th className="px-4 py-2.5">Transformation</th>
                        <th className="px-4 py-2.5">Destination Field</th>
                        <th className="px-4 py-2.5 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {mappings.map((m) => (
                        <tr key={m.id} className="hover:bg-slate-900/50">
                          <td className="px-4 py-2.5">
                            <select
                              value={m.sourceColumn}
                              onChange={(e) => handleUpdateMapping(m.id, { sourceColumn: e.target.value })}
                              className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-slate-200"
                            >
                              {sourceColumns.map((col) => (
                                <option key={col.name} value={col.name}>
                                  {col.name}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="px-4 py-2.5">
                            <select
                              value={m.transform}
                              onChange={(e) =>
                                handleUpdateMapping(m.id, { transform: e.target.value as TransformType })
                              }
                              className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300 font-medium"
                            >
                              <option value="direct">Direct</option>
                              <option value="uppercase">UPPERCASE</option>
                              <option value="lowercase">lowercase</option>
                              <option value="trim">Trim Whitespace</option>
                              <option value="sha256">SHA-256 Hashing</option>
                              <option value="to_integer">Cast to Integer</option>
                              <option value="to_float">Cast to Float</option>
                              <option value="to_boolean">Cast to Boolean</option>
                              <option value="default_value">Default Value</option>
                            </select>
                          </td>
                          <td className="px-4 py-2.5">
                            <select
                              value={m.destinationField}
                              onChange={(e) => handleUpdateMapping(m.id, { destinationField: e.target.value })}
                              className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-cyan-300"
                            >
                              {destFields.map((f) => (
                                <option key={f.name} value={f.name}>
                                  {f.name} {f.required ? '*(Req)' : ''}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="px-4 py-2.5 text-right">
                            <button
                              onClick={() => handleRemoveMapping(m.id)}
                              className="text-slate-500 hover:text-rose-400 p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* STEP 5: SCHEDULE & REVIEW */}
          {currentStep === 5 && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Schedule & Final Review</h3>
                <p className="text-xs text-slate-400">Name your reverse ETL sync pipeline and set run frequency</p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-300 block mb-1">Pipeline Name</label>
                  <input
                    type="text"
                    value={syncName}
                    onChange={(e) => setSyncName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-300 block mb-1">Description</label>
                  <input
                    type="text"
                    value={syncDescription}
                    onChange={(e) => setSyncDescription(e.target.value)}
                    placeholder="e.g. Sync high intent PQL scores to sales reps in Salesforce"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-300 block mb-1.5">Schedule Cadence</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'hourly', label: 'Hourly' },
                      { id: 'daily', label: 'Daily (04:00 UTC)' },
                      { id: 'dbt_cloud_webhook', label: 'dbt Cloud Hook' },
                      { id: 'manual', label: 'Manual Only' },
                    ].map((cad) => (
                      <button
                        key={cad.id}
                        type="button"
                        onClick={() => setScheduleType(cad.id as any)}
                        className={`p-2.5 rounded-lg border text-xs font-medium transition-colors ${
                          scheduleType === cad.id
                            ? 'border-indigo-500 bg-indigo-950/40 text-white'
                            : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {cad.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Review Box */}
              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2 text-xs">
                <div className="font-semibold text-slate-300 mb-2">Summary of Pipeline Configuration</div>
                <div className="grid grid-cols-2 gap-2 text-slate-400">
                  <div>
                    Source: <strong className="text-slate-200">{selectedModel.name}</strong>
                  </div>
                  <div>
                    Destination: <strong className="text-slate-200">{selectedDest.name}</strong> ({selectedDestObject})
                  </div>
                  <div>
                    Sync Mode: <span className="font-mono uppercase text-slate-200">{syncMode}</span>
                  </div>
                  <div>
                    Match Key: <code className="text-indigo-300 font-mono">{sourceIdentifier} ⇄ {destinationIdentifier}</code>
                  </div>
                  <div>
                    Mapped Fields: <strong className="text-slate-200">{mappings.length} fields</strong>
                  </div>
                  <div>
                    Initial Run: <span className="text-emerald-400">Ready to execute</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Wizard Footer Controls */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/60">
          <button
            type="button"
            onClick={() => {
              if (currentStep === 1) onClose();
              else setCurrentStep((prev) => (prev - 1) as any);
            }}
            className="px-4 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            {currentStep === 1 ? 'Cancel' : 'Back'}
          </button>

          <div className="flex items-center gap-2">
            {currentStep < 5 ? (
              <button
                type="button"
                onClick={() => {
                  if (currentStep === 3 && mappings.length === 0) {
                    handleAutoMap();
                  }
                  setCurrentStep((prev) => (prev + 1) as any);
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <span>Continue</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleFinish}
                className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Deploy & Activate Sync</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
