import React, { useState } from 'react';
import { SyncConfig, Destination, DataModel } from '../types/reverse-etl';
import {
  Search,
  Filter,
  Play,
  Eye,
  Sliders,
  AlertTriangle,
  CheckCircle2,
  PauseCircle,
  Plus,
  ArrowRight,
  Clock,
  Sparkles,
  RefreshCw,
} from 'lucide-react';

interface SyncsListProps {
  syncs: SyncConfig[];
  destinations: Destination[];
  models: DataModel[];
  onTriggerSync: (sync: SyncConfig, isDryRun?: boolean) => void;
  onOpenSyncDetail: (sync: SyncConfig) => void;
  onToggleSyncEnabled: (syncId: string) => void;
  onOpenCreateSync: () => void;
}

export const SyncsList: React.FC<SyncsListProps> = ({
  syncs,
  destinations,
  models,
  onTriggerSync,
  onOpenSyncDetail,
  onToggleSyncEnabled,
  onOpenCreateSync,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'healthy' | 'drift' | 'paused'>('all');
  const [destFilter, setDestFilter] = useState<string>('all');

  const filteredSyncs = syncs.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.sourceIdentifier.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.destinationObject.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'healthy'
        ? s.status === 'healthy' && s.enabled
        : statusFilter === 'drift'
        ? s.status === 'drift_detected'
        : !s.enabled;

    const matchesDest = destFilter === 'all' || s.destinationId === destFilter;

    return matchesSearch && matchesStatus && matchesDest;
  });

  return (
    <div className="space-y-5">
      {/* Top action & filtering row */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-3 flex-1 max-w-xl">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search syncs by name, identifier, or destination object..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <select
            value={destFilter}
            onChange={(e) => setDestFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 transition-colors shrink-0"
          >
            <option value="all">All Destinations</option>
            {destinations.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          {/* Status filter buttons */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                statusFilter === 'all' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({syncs.length})
            </button>
            <button
              onClick={() => setStatusFilter('healthy')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                statusFilter === 'healthy' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Healthy
            </button>
            <button
              onClick={() => setStatusFilter('drift')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
                statusFilter === 'drift' ? 'bg-slate-800 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Drift</span>
              {syncs.some((s) => s.status === 'drift_detected') && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
              )}
            </button>
          </div>

          <button
            onClick={onOpenCreateSync}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Create Sync</span>
          </button>
        </div>
      </div>

      {/* Syncs List Cards */}
      <div className="space-y-3">
        {filteredSyncs.length === 0 ? (
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-12 text-center space-y-3">
            <Sliders className="w-8 h-8 text-slate-500 mx-auto" />
            <h3 className="text-sm font-semibold text-slate-300">No matching reverse ETL syncs</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Try adjusting your search query or create a new sync to send warehouse data to downstream CRMs and ad networks.
            </p>
            <button
              onClick={onOpenCreateSync}
              className="mt-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors"
            >
              + Create New Reverse ETL Sync
            </button>
          </div>
        ) : (
          filteredSyncs.map((sync) => {
            const dest = destinations.find((d) => d.id === sync.destinationId);
            const model = models.find((m) => m.id === sync.sourceModelId);

            return (
              <div
                key={sync.id}
                className="bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-5 transition-all space-y-4"
              >
                {/* Header line */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <h3
                        onClick={() => onOpenSyncDetail(sync)}
                        className="text-base font-semibold text-white hover:text-indigo-400 transition-colors cursor-pointer"
                      >
                        {sync.name}
                      </h3>

                      {sync.status === 'drift_detected' ? (
                        <span className="text-xs font-mono text-amber-400 bg-amber-950/80 border border-amber-800/60 px-2 py-0.5 rounded flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Drift Detected</span>
                        </span>
                      ) : sync.enabled ? (
                        <span className="text-xs font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2 py-0.5 rounded flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Active</span>
                        </span>
                      ) : (
                        <span className="text-xs font-mono text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded flex items-center gap-1">
                          <PauseCircle className="w-3 h-3" />
                          <span>Paused</span>
                        </span>
                      )}

                      <span className="text-xs font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                        {sync.syncMode}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
                      {sync.description}
                    </p>
                  </div>

                  {/* Right side interactive actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onTriggerSync(sync, true)}
                      title="Inspect diff and payload preview without sending API requests"
                      className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/90 hover:bg-slate-700 border border-slate-700/80 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-400" />
                      <span>Dry Run</span>
                    </button>

                    <button
                      onClick={() => onTriggerSync(sync, false)}
                      className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-indigo-600/30"
                    >
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>Run Sync</span>
                    </button>
                  </div>
                </div>

                {/* Pipeline visual path */}
                <div className="p-3 bg-slate-950/60 border border-slate-800/60 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                  {/* Left: Source Model -> Destination */}
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400">Source:</span>
                      <span className="font-semibold text-slate-200">{model?.name || sync.sourceModelId}</span>
                      <span className="text-slate-500 font-mono">({model?.type.toUpperCase()})</span>
                    </div>

                    <ArrowRight className="w-3.5 h-3.5 text-indigo-400 shrink-0" />

                    <div className="flex items-center gap-2">
                      <span className="text-slate-400">Destination:</span>
                      <span className="font-semibold text-slate-200">{dest?.name || sync.destinationId}</span>
                      <span className="font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 px-1.5 py-0.2 rounded">
                        {sync.destinationObject}
                      </span>
                    </div>
                  </div>

                  {/* Right: Key identifier mapping & Schedule */}
                  <div className="flex items-center gap-4 text-slate-400 flex-wrap">
                    <div>
                      <span>Match Key: </span>
                      <code className="text-indigo-300 font-mono font-medium">
                        {sync.sourceIdentifier} ⇄ {sync.destinationIdentifier}
                      </code>
                    </div>
                    <span>·</span>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span className="capitalize">{sync.schedule.type.replace('_', ' ')}</span>
                    </div>
                    <span>·</span>
                    <button
                      onClick={() => onOpenSyncDetail(sync)}
                      className="text-indigo-400 hover:text-indigo-300 font-medium inline-flex items-center gap-1"
                    >
                      <span>{sync.mappings.length} Field Mappings</span>
                      <Sliders className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Bottom line: Execution telemetry & Records synced */}
                <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                  <div className="flex items-center gap-3">
                    <span>
                      Total Synced:{' '}
                      <strong className="text-slate-200 font-mono tabular-nums">
                        {sync.totalSyncedCount.toLocaleString()}
                      </strong>{' '}
                      records
                    </span>
                    <span>·</span>
                    <span>
                      Last Run:{' '}
                      <strong className="text-slate-200 font-medium">{sync.lastRunAt || 'Never'}</strong>
                      {sync.lastRunDurationSec ? ` (${sync.lastRunDurationSec}s)` : ''}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onToggleSyncEnabled(sync.id)}
                      className="text-xs text-slate-400 hover:text-slate-200 underline font-medium"
                    >
                      {sync.enabled ? 'Pause Sync' : 'Resume Sync'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
