import React, { useState } from 'react';
import {
  initialWarehouses,
  initialModels,
  initialDestinations,
  initialSyncs,
  initialRunHistory,
  initialQuarantinedRecords,
  initialDriftAlerts,
} from './data/mockData';
import {
  SyncConfig,
  DataModel,
  Destination,
  WarehouseSource,
  SyncRunLog,
  QuarantinedRecord,
  SchemaDriftAlert,
  FieldMapping,
} from './types/reverse-etl';
import { Header, NavigationTab } from './components/Header';
import { OperationalDashboard } from './components/OperationalDashboard';
import { SyncsList } from './components/SyncsList';
import { SyncDetailModal } from './components/SyncDetailModal';
import { CreateSyncWizard } from './components/CreateSyncWizard';
import { ModelsStudio } from './components/ModelsStudio';
import { SourcesView } from './components/SourcesView';
import { DestinationsView } from './components/DestinationsView';
import { SchemaDriftView } from './components/SchemaDriftView';
import { QuarantineView } from './components/QuarantineView';
import { LiveSyncRunnerModal } from './components/LiveSyncRunnerModal';
import { Zap, Play, Sparkles, CheckCircle2, ShieldCheck, ArrowRight } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');

  // Application State
  const [warehouses, setWarehouses] = useState<WarehouseSource[]>(initialWarehouses);
  const [models, setModels] = useState<DataModel[]>(initialModels);
  const [destinations, setDestinations] = useState<Destination[]>(initialDestinations);
  const [syncs, setSyncs] = useState<SyncConfig[]>(initialSyncs);
  const [runs, setRuns] = useState<SyncRunLog[]>(initialRunHistory);
  const [quarantinedRecords, setQuarantinedRecords] = useState<QuarantinedRecord[]>(
    initialQuarantinedRecords
  );
  const [driftAlerts, setDriftAlerts] = useState<SchemaDriftAlert[]>(initialDriftAlerts);

  // Modals
  const [activeDetailSync, setActiveDetailSync] = useState<SyncConfig | null>(null);
  const [isCreateSyncOpen, setIsCreateSyncOpen] = useState(false);
  const [activeRunnerSync, setActiveRunnerSync] = useState<{
    sync: SyncConfig;
    isDryRun: boolean;
  } | null>(null);
  const [isGlobalSyncing, setIsGlobalSyncing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Actions
  const handleTriggerSync = (sync: SyncConfig, isDryRun: boolean = false) => {
    setActiveRunnerSync({ sync, isDryRun });
  };

  const handleRunFinished = (newRun: SyncRunLog) => {
    setRuns((prev) => [newRun, ...prev]);

    // Update sync statistics
    setSyncs((prev) =>
      prev.map((s) => {
        if (s.id === newRun.syncId) {
          return {
            ...s,
            lastRunAt: 'Just now',
            lastRunDurationSec: newRun.durationSec,
            totalSyncedCount: s.totalSyncedCount + newRun.recordsAdded + newRun.recordsUpdated,
          };
        }
        return s;
      })
    );

    // If modal was open, refresh the detail copy
    if (activeDetailSync && activeDetailSync.id === newRun.syncId) {
      setActiveDetailSync((prev) =>
        prev
          ? {
              ...prev,
              lastRunAt: 'Just now',
              lastRunDurationSec: newRun.durationSec,
              totalSyncedCount: prev.totalSyncedCount + newRun.recordsAdded + newRun.recordsUpdated,
            }
          : null
      );
    }

    showToast(
      `${newRun.isDryRun ? 'Dry run completed' : 'Sync completed'} for ${newRun.syncName} (+${newRun.recordsAdded} adds, ~${newRun.recordsUpdated} updates)`
    );
  };

  const handleUpdateMappings = (syncId: string, updatedMappings: FieldMapping[]) => {
    setSyncs((prev) =>
      prev.map((s) => (s.id === syncId ? { ...s, mappings: updatedMappings } : s))
    );
    if (activeDetailSync && activeDetailSync.id === syncId) {
      setActiveDetailSync((prev) => (prev ? { ...prev, mappings: updatedMappings } : null));
    }
    showToast('Field mappings updated successfully');
  };

  const handleToggleSyncEnabled = (syncId: string) => {
    setSyncs((prev) =>
      prev.map((s) => (s.id === syncId ? { ...s, enabled: !s.enabled } : s))
    );
    showToast('Sync status toggled');
  };

  const handleCreateSync = (newSync: SyncConfig) => {
    setSyncs((prev) => [newSync, ...prev]);
    setIsCreateSyncOpen(false);
    showToast(`Reverse ETL Sync "${newSync.name}" created and activated!`);
    setActiveTab('syncs');
  };

  const handleCreateModel = (newModel: DataModel) => {
    setModels((prev) => [newModel, ...prev]);
    showToast(`Warehouse model "${newModel.name}" compiled and saved.`);
  };

  const handleAddWarehouse = (newWh: WarehouseSource) => {
    setWarehouses((prev) => [newWh, ...prev]);
    showToast(`Warehouse "${newWh.name}" connected and cataloged.`);
  };

  const handleAddDestination = (newDest: Destination) => {
    setDestinations((prev) => [newDest, ...prev]);
    showToast(`Destination "${newDest.name}" connected.`);
  };

  // Auto-Remap Drift logic
  const handleAutoRemapDrift = (syncId: string) => {
    // Cast affected field to string or correct type
    setSyncs((prev) =>
      prev.map((s) => {
        if (s.id === syncId) {
          const updatedMappings = s.mappings.map((m) => {
            if (m.sourceColumn === 'active_bugs_count') {
              return { ...m, transform: 'to_integer' as const };
            }
            return m;
          });
          return {
            ...s,
            status: 'healthy' as const,
            mappings: updatedMappings,
            driftAlert: undefined,
          };
        }
        return s;
      })
    );

    // Update alert status
    setDriftAlerts((prev) =>
      prev.map((a) => (a.syncId === syncId ? { ...a, status: 'resolved' as const } : a))
    );

    if (activeDetailSync && activeDetailSync.id === syncId) {
      setActiveDetailSync((prev) =>
        prev
          ? {
              ...prev,
              status: 'healthy' as const,
              driftAlert: undefined,
            }
          : null
      );
    }

    showToast('Schema drift resolved: Auto-remapped with type casting and cleared alert!');
  };

  const handleDismissDriftAlert = (alertId: string) => {
    setDriftAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, status: 'dismissed' as const } : a))
    );
    showToast('Drift alert dismissed.');
  };

  const handleRetryQuarantine = (recordId: string) => {
    setQuarantinedRecords((prev) =>
      prev.map((q) => (q.id === recordId ? { ...q, retryStatus: 'resolved' as const } : q))
    );
    showToast('Record re-dispatched and accepted by destination API with 200 OK.');
  };

  const handleIgnoreQuarantine = (recordId: string) => {
    setQuarantinedRecords((prev) => prev.filter((q) => q.id !== recordId));
    showToast('Quarantined record dismissed.');
  };

  const handleQuickRunAll = () => {
    setIsGlobalSyncing(true);
    setTimeout(() => {
      setIsGlobalSyncing(false);
      showToast('All 4 enabled sync pipelines evaluated against latest warehouse snapshots.');
    }, 1800);
  };

  const unresolvedDriftCount = driftAlerts.filter((a) => a.status === 'unresolved').length;
  const activeQuarantineCount = quarantinedRecords.filter((q) => q.retryStatus === 'pending').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Strict 3-zone Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCreateSync={() => setIsCreateSyncOpen(true)}
        driftCount={unresolvedDriftCount}
        quarantineCount={activeQuarantineCount}
        onQuickRunAll={handleQuickRunAll}
        isGlobalSyncing={isGlobalSyncing}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 shadow-2xl text-xs text-white font-medium flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'overview' && (
          <OperationalDashboard
            syncs={syncs}
            runs={runs}
            destinations={destinations}
            warehouses={warehouses}
            driftAlerts={driftAlerts}
            onTriggerSync={handleTriggerSync}
            onOpenSyncDetail={(sync) => setActiveDetailSync(sync)}
            onNavigateTab={setActiveTab}
            onOpenCreateSync={() => setIsCreateSyncOpen(true)}
          />
        )}

        {activeTab === 'syncs' && (
          <SyncsList
            syncs={syncs}
            destinations={destinations}
            models={models}
            onTriggerSync={handleTriggerSync}
            onOpenSyncDetail={(sync) => setActiveDetailSync(sync)}
            onToggleSyncEnabled={handleToggleSyncEnabled}
            onOpenCreateSync={() => setIsCreateSyncOpen(true)}
          />
        )}

        {activeTab === 'models' && (
          <ModelsStudio
            models={models}
            warehouses={warehouses}
            onCreateModel={handleCreateModel}
          />
        )}

        {activeTab === 'sources' && (
          <SourcesView
            warehouses={warehouses}
            onAddWarehouse={handleAddWarehouse}
          />
        )}

        {activeTab === 'destinations' && (
          <DestinationsView
            destinations={destinations}
            onAddDestination={handleAddDestination}
          />
        )}

        {activeTab === 'drift' && (
          <SchemaDriftView
            driftAlerts={driftAlerts}
            syncs={syncs}
            onAutoRemap={handleAutoRemapDrift}
            onDismissAlert={handleDismissDriftAlert}
          />
        )}

        {activeTab === 'quarantine' && (
          <QuarantineView
            quarantinedRecords={quarantinedRecords}
            onRetryRecord={handleRetryQuarantine}
            onIgnoreRecord={handleIgnoreQuarantine}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-6 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">VectorSync Operational Engine</span>
            <span>·</span>
            <span>Reverse ETL Platform</span>
            <span>·</span>
            <span className="text-emerald-400 font-mono">Status: All Systems Operational</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500">
            <span>Snowflake / BigQuery / Databricks / Salesforce / HubSpot / Google Ads</span>
          </div>
        </div>
      </footer>

      {/* Sync Detail Modal */}
      {activeDetailSync && (
        <SyncDetailModal
          sync={activeDetailSync}
          model={
            models.find((m) => m.id === activeDetailSync.sourceModelId) || models[0]
          }
          destination={
            destinations.find((d) => d.id === activeDetailSync.destinationId) ||
            destinations[0]
          }
          runs={runs}
          onClose={() => setActiveDetailSync(null)}
          onUpdateMappings={handleUpdateMappings}
          onTriggerSync={handleTriggerSync}
          onAutoRemapDrift={handleAutoRemapDrift}
        />
      )}

      {/* Create Sync Wizard */}
      {isCreateSyncOpen && (
        <CreateSyncWizard
          models={models}
          destinations={destinations}
          onClose={() => setIsCreateSyncOpen(false)}
          onCreateSync={handleCreateSync}
        />
      )}

      {/* Live Sync Runner Execution Modal */}
      {activeRunnerSync && (
        <LiveSyncRunnerModal
          sync={activeRunnerSync.sync}
          isDryRun={activeRunnerSync.isDryRun}
          onClose={() => setActiveRunnerSync(null)}
          onRunFinished={handleRunFinished}
        />
      )}
    </div>
  );
}
